#include "Function.h"

double Function::countTestF(double _Xi, double _Vi)
{
	double f = ((-1.5) * _Vi);

	return f;
}

double Function::accurateSlnTestF(double Xi)
{
	return (exp((-1.5) * Xi));
}

void Function::setCoefForSystem(double _A, double _B)
{
	A = _A;
	B = _B;
}

double Function::countFirstMainF(double _Xi, double _Vi)
{
	double f = (pow(_Vi, 2)/pow((1 + pow(_Xi, 2)), (1/3) )) + _Vi - pow(_Vi, 3)* sin(10* _Xi) ;
	return f;
}

double Function::countF1forSystem(double V1i, double V2i)
{
	return V2i;
}

double Function::countF2forSystem(double V1i, double V2i)
{
	return -A* (V2i*V2i) - B* V1i;
}
