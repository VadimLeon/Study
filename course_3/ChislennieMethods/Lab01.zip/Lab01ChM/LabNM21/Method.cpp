#include "Method.h"

void Method::doHalfH()
{
	H = H / 2;
}

void Method::doDoubleH()
{
	H = H * 2;
}

double Method::getH()
{
	return H;
}

double Method::getHalfH()
{
	return H / 2;
}


double Method::getX0()
{
	return X0;
}

double Method::getV0()
{
	return V0;
}

double Method::getV10()
{
	return V10;
}

double Method::getV20()
{
	return V20;
}

double Method::getXi()
{
	return Xi;
}

double Method::getui(double xi)
{
	double f = Function::accurateSlnTestF(xi);
	return (V0* f);
}

double Method::getVi()
{
	return Vi;
}

double Method::getV1i()
{
	return V1i;
}

double Method::getV2i()
{
	return V2i;
}

int Method::getmaxSteps()
{
	return maxSteps;
}
double Method::getEpsBorder()
{
	return epsBorder;
}

double Method::getEpsError()
{
	return epsError;
}

double Method::getcontrolLocalFault()
{
	return controlLocalFault;
}

double Method::getaccuracyBorder()
{
	return accuracyBorder;
}

void Method::setH(double _H)
{
	H = _H;
}

void Method::setX0(double _X0)
{
	X0 = _X0;

}

void Method::setEpsBorder(double _epsBorder)
{
	epsBorder = _epsBorder;
}

void Method::setEpsError(double _epsError)
{
	epsError = _epsError;
}

void Method::setV0(double _V0)
{
	V0 = _V0;
}

void Method::setV10(double _V10)
{
	V10 = _V10;
}

void Method::setV20(double _V20)
{
	V20 = _V20;
}

void Method::setXi(double _Xi)
{
	Xi = _Xi;
}


void Method::setVi(double _Vi)
{
	Vi = _Vi;
}

void Method::setV1i(double _V1i)
{
	V1i = _V1i;
}

void Method::setV2i(double _V2i)
{
	V2i = _V2i;
}

void Method::setmaxSteps(int _maxSteps)
{
	maxSteps = _maxSteps;
}

void Method::setcontrolLocalFault(double _controlLocalFault)
{
	controlLocalFault = _controlLocalFault;
}

void Method::setaccuracyBorder(double _accuracyBorder)
{
	accuracyBorder = _accuracyBorder;
}

void Method::RK4forFirstMain(double h)
{
	double k1, k2, k3, k4;
	double xi, vi;

	xi = Xi + h;
	k1 = countFirstMainF(Xi, Vi);
	k2 = countFirstMainF(Xi + h / 2, Vi + h / 2 * k1);
	k3 = countFirstMainF(Xi + h / 2, Vi + h / 2 * k2);
	k4 = countFirstMainF(Xi + h, Vi + h * k3);
	vi = Vi + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4);
	
	prevX = Xi;
	prevV = Vi;
	Xi = xi;
	Vi = vi;

}

void Method::RK4forTest(double h)
{
	double k1, k2, k3, k4;
	double xi, vi;

	xi = Xi + h;
	k1 = countTestF(Xi, Vi);
	k2 = countTestF(Xi + h / 2, Vi + h / 2 * k1);
	k3 = countTestF(Xi + h / 2, Vi + h / 2 * k2);
	k4 = countTestF(Xi + h, Vi + h * k3);
	vi = Vi + h / 6 * (k1 + 2 * k2 + 2 * k3 + k4);
	
	prevX = Xi;
	prevV = Vi;
	Xi = xi;
	Vi = vi;
}

void Method::RK4forSystem(double h)
{
	double k11, k21, k12, k22, k13, k23, k14, k24;
	double xi, v1i, v2i;

	xi = Xi + h;
	k11 = countF1forSystem(V1i, V2i);
	k21 = countF2forSystem(V1i, V2i);
	k12 = countF1forSystem(V1i + h / 2 * k11, V2i + h / 2 * k21);
	k22 = countF2forSystem(V1i + h / 2 * k11, V2i + h / 2 * k21);
	k13 = countF1forSystem(V1i + h / 2 * k12, V2i + h / 2 * k22);
	k23 = countF2forSystem(V1i + h / 2 * k12, V2i + h / 2 * k22);
	k14 = countF1forSystem(V1i + h * k13, V2i + h * k23);
	k24 = countF2forSystem(V1i + h * k13, V2i + h * k23);
	v1i = V1i + h / 6 * (k11 + 2 * k12 + 2 * k13 + k14);
	v2i = V2i + h / 6 * (k21 + 2 * k22 + 2 * k23 + k24);

	prevX = Xi;
	prevV1 = V1i;
	prevV2 = V2i;
	Xi = xi;
	V1i = v1i;
	V2i = v2i;

}

double Method::getCountS(double vi, double v2i)
{
	double S = (v2i - vi) / (pow(2, 4) - 1);
	return fabs(S);
}

double Method::getCountSforSystem(double V1i, double V12i, double V2i, double V22i)
{
	return sqrt(((V12i - V1i)*(V12i - V1i)) / 225);
}


double Method::getLocalControl()
{
	double Eps = epsError;
	Eps = Eps / pow(2, 4 + 1);
	return Eps;
}

bool Method::tooBig(double vi, double v2i)
{
	double s = getCountS(vi, v2i);
	if (s > epsError)
	{
		return true;
	}

	return false;
}

bool Method::tooSmall(double vi, double v2i)
{
	bool tmp;
	double s = getCountS(vi, v2i);
	double Eps = getLocalControl();
	if (s < Eps)
		return true;

	return false;
}

bool Method::tooBigforSystem(double V1i, double V12i, double V2i, double V22i)
{
	double s = getCountSforSystem(V1i, V12i, V2i, V22i);
	if (s > epsError)
	{
		return true;
	}

	return false;
}

bool Method::tooSmallforSystem(double V1i, double V12i, double V2i, double V22i)
{
	bool tmp;
	double s = getCountSforSystem(V1i, V12i, V2i, V22i);
	double Eps = getLocalControl();
	if (s < Eps)
		return true;

	return false;
}

void Method::goBack()
{
	Xi = prevX;
	Vi = prevV;
}

void Method::goBackforSystem()
{
	Xi = prevX;
	V1i = prevV1;
	V2i = prevV2;
}