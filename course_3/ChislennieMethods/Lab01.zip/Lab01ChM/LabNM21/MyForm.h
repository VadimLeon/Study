#pragma once
#include <math.h>
#include "Method.h"


namespace LabNM21 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace ZedGraph;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: bool flag = true;
	private: ZedGraph::ZedGraphControl^  zedGraphControl1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::DataGridView^  dataGridView1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  X;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  F_1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  F_2;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  textBox3;
	private: ZedGraph::ZedGraphControl^  zedGraphControl2;
	private: System::Windows::Forms::TabControl^  tabControl1;
	private: System::Windows::Forms::TabPage^  tabPage1;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::DataGridView^  dataGridView2;
	private: System::Windows::Forms::TabPage^  tabPage2;
	private: System::Windows::Forms::TabPage^  tabPage3;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::TextBox^  textBox5;
	private: System::Windows::Forms::TextBox^  textBox4;
	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::GroupBox^  groupBox3;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::TextBox^  textBox7;
	private: System::Windows::Forms::Label^  label8;
	private: System::Windows::Forms::Label^  label9;
	private: System::Windows::Forms::TextBox^  textBox8;
	private: System::Windows::Forms::CheckedListBox^  checkedListBox1;
	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Label^  label10;
	private: System::Windows::Forms::TextBox^  textBox9;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  i;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  hi;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  xi;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  vi;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  v2i;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  viv2i;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  OLP;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  halfh;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  doubleh;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  ui;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  uivi;
	private: System::Windows::Forms::Button^  button3;
	private: System::Windows::Forms::GroupBox^  groupBox5;
	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::Label^  label16;
	private: System::Windows::Forms::Label^  label15;
	private: System::Windows::Forms::Label^  label14;
	private: System::Windows::Forms::Label^  label13;
	private: System::Windows::Forms::Label^  label12;
	private: System::Windows::Forms::Label^  label11;
	private: System::Windows::Forms::Label^  label18;
	private: System::Windows::Forms::Label^  label17;

private: System::Windows::Forms::GroupBox^  groupBox7;
private: System::Windows::Forms::GroupBox^  groupBox6;
private: System::Windows::Forms::TextBox^  textBox18;
private: System::Windows::Forms::Label^  label20;
private: System::Windows::Forms::Label^  label19;
private: System::Windows::Forms::PictureBox^  pictureBox2;
private: System::Windows::Forms::DataGridView^  dataGridView3;
private: System::Windows::Forms::Button^  button5;
private: System::Windows::Forms::Button^  button4;
private: System::Windows::Forms::GroupBox^  groupBox9;
private: ZedGraph::ZedGraphControl^  zedGraphControl3;
private: System::Windows::Forms::Label^  label21;
private: System::Windows::Forms::CheckedListBox^  checkedListBox2;
private: System::Windows::Forms::TextBox^  textBox22;
private: System::Windows::Forms::Label^  label24;
private: System::Windows::Forms::Label^  label23;
private: System::Windows::Forms::Label^  label22;
private: System::Windows::Forms::TextBox^  textBox21;
private: System::Windows::Forms::TextBox^  textBox19;
private: System::Windows::Forms::TextBox^  textBox20;
private: System::Windows::Forms::GroupBox^  groupBox4;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  i1;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  h1i;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  xi1;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Vi1;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Vi11;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Vi111;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  S1;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  half1;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  double1;
private: System::Windows::Forms::GroupBox^  groupBox8;
private: System::Windows::Forms::TextBox^  textBox23;
private: System::Windows::Forms::Label^  label25;
private: System::Windows::Forms::CheckedListBox^  checkedListBox3;
private: System::Windows::Forms::Label^  label36;
private: System::Windows::Forms::Label^  label35;
private: System::Windows::Forms::Label^  label34;
private: System::Windows::Forms::Label^  label33;
private: System::Windows::Forms::Label^  label32;
private: System::Windows::Forms::Label^  label31;
private: System::Windows::Forms::Label^  label30;
private: System::Windows::Forms::Label^  label29;
private: System::Windows::Forms::Label^  label28;
private: System::Windows::Forms::Label^  label27;
private: System::Windows::Forms::Label^  label26;
private: System::Windows::Forms::Label^  label40;
private: System::Windows::Forms::Label^  label39;
private: System::Windows::Forms::Label^  label38;
private: System::Windows::Forms::Label^  label37;
private: System::Windows::Forms::Label^  label64;
private: System::Windows::Forms::Label^  label60;
private: System::Windows::Forms::Label^  label59;
private: System::Windows::Forms::Label^  label58;
private: System::Windows::Forms::Label^  label57;
private: System::Windows::Forms::Label^  label56;
private: System::Windows::Forms::Label^  label55;
private: System::Windows::Forms::Label^  label54;
private: System::Windows::Forms::Label^  label53;
private: System::Windows::Forms::Label^  label52;
private: System::Windows::Forms::Label^  label51;
private: System::Windows::Forms::Label^  label50;
private: System::Windows::Forms::Label^  label49;
private: System::Windows::Forms::Label^  label48;
private: System::Windows::Forms::Label^  label47;
private: System::Windows::Forms::Label^  label46;
private: System::Windows::Forms::Label^  label45;
private: System::Windows::Forms::Label^  label44;
private: System::Windows::Forms::Label^  label43;
private: System::Windows::Forms::Label^  label42;
private: System::Windows::Forms::Label^  label41;
private: System::Windows::Forms::PictureBox^  pictureBox3;
private: System::Windows::Forms::GroupBox^  groupBox13;
private: System::Windows::Forms::GroupBox^  groupBox12;
private: System::Windows::Forms::GroupBox^  groupBox11;
private: System::Windows::Forms::TextBox^  textBox12;
private: System::Windows::Forms::Label^  label63;
private: System::Windows::Forms::TextBox^  textBox10;
private: System::Windows::Forms::Label^  label61;
private: System::Windows::Forms::GroupBox^  groupBox10;
private: ZedGraph::ZedGraphControl^  zedGraphControl5;
private: ZedGraph::ZedGraphControl^  zedGraphControl4;
private: System::Windows::Forms::Button^  button6;
private: System::Windows::Forms::DataGridView^  dataGridView4;
private: System::Windows::Forms::Button^  button7;
private: System::Windows::Forms::Label^  label67;
private: System::Windows::Forms::CheckedListBox^  checkedListBox4;
private: System::Windows::Forms::TextBox^  textBox14;
private: System::Windows::Forms::Label^  label66;
private: System::Windows::Forms::Label^  label65;
private: System::Windows::Forms::Label^  label62;
private: System::Windows::Forms::TextBox^  textBox13;
private: System::Windows::Forms::TextBox^  textBox11;
private: System::Windows::Forms::TextBox^  textBox6;
private: System::Windows::Forms::Label^  label69;
private: System::Windows::Forms::Label^  label68;
private: System::Windows::Forms::TextBox^  textBox16;
private: System::Windows::Forms::TextBox^  textBox15;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  i3;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  hi3;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  xi3;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Vi3;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  V2i3;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  V1iii;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  V2iii;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  V1iiii;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  V2iiii;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  Siii;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  halfiii;
private: System::Windows::Forms::DataGridViewTextBoxColumn^  doubleiii;
private: System::Windows::Forms::Label^  label83;
private: System::Windows::Forms::Label^  label82;
private: System::Windows::Forms::Label^  label81;
private: System::Windows::Forms::Label^  label80;
private: System::Windows::Forms::Label^  label79;
private: System::Windows::Forms::Label^  label78;
private: System::Windows::Forms::Label^  label77;
private: System::Windows::Forms::Label^  label76;
private: System::Windows::Forms::Label^  label75;
private: System::Windows::Forms::Label^  label74;
private: System::Windows::Forms::Label^  label73;
private: System::Windows::Forms::Label^  label72;
private: System::Windows::Forms::Label^  label71;
private: System::Windows::Forms::Label^  label70;
private: System::Windows::Forms::Label^  label89;
private: System::Windows::Forms::Label^  label88;
private: System::Windows::Forms::Label^  label87;
private: System::Windows::Forms::Label^  label86;
private: System::Windows::Forms::Label^  label85;
private: System::Windows::Forms::Label^  label84;
private: System::Windows::Forms::CheckBox^  checkBox1;

	protected:
	private: System::ComponentModel::IContainer^  components;

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->zedGraphControl2 = (gcnew ZedGraph::ZedGraphControl());
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->checkedListBox1 = (gcnew System::Windows::Forms::CheckedListBox());
			this->label9 = (gcnew System::Windows::Forms::Label());
			this->textBox8 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox5 = (gcnew System::Windows::Forms::GroupBox());
			this->label40 = (gcnew System::Windows::Forms::Label());
			this->label39 = (gcnew System::Windows::Forms::Label());
			this->label38 = (gcnew System::Windows::Forms::Label());
			this->label37 = (gcnew System::Windows::Forms::Label());
			this->label36 = (gcnew System::Windows::Forms::Label());
			this->label35 = (gcnew System::Windows::Forms::Label());
			this->label34 = (gcnew System::Windows::Forms::Label());
			this->label33 = (gcnew System::Windows::Forms::Label());
			this->label32 = (gcnew System::Windows::Forms::Label());
			this->label31 = (gcnew System::Windows::Forms::Label());
			this->label30 = (gcnew System::Windows::Forms::Label());
			this->label29 = (gcnew System::Windows::Forms::Label());
			this->label28 = (gcnew System::Windows::Forms::Label());
			this->label27 = (gcnew System::Windows::Forms::Label());
			this->label26 = (gcnew System::Windows::Forms::Label());
			this->label18 = (gcnew System::Windows::Forms::Label());
			this->label17 = (gcnew System::Windows::Forms::Label());
			this->label16 = (gcnew System::Windows::Forms::Label());
			this->label15 = (gcnew System::Windows::Forms::Label());
			this->label14 = (gcnew System::Windows::Forms::Label());
			this->label13 = (gcnew System::Windows::Forms::Label());
			this->label12 = (gcnew System::Windows::Forms::Label());
			this->label11 = (gcnew System::Windows::Forms::Label());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->textBox7 = (gcnew System::Windows::Forms::TextBox());
			this->label8 = (gcnew System::Windows::Forms::Label());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->label10 = (gcnew System::Windows::Forms::Label());
			this->textBox9 = (gcnew System::Windows::Forms::TextBox());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->textBox5 = (gcnew System::Windows::Forms::TextBox());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->dataGridView2 = (gcnew System::Windows::Forms::DataGridView());
			this->i = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->hi = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->xi = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->vi = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->v2i = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->viv2i = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->OLP = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->halfh = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->doubleh = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->ui = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->uivi = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->groupBox8 = (gcnew System::Windows::Forms::GroupBox());
			this->textBox23 = (gcnew System::Windows::Forms::TextBox());
			this->label25 = (gcnew System::Windows::Forms::Label());
			this->checkedListBox3 = (gcnew System::Windows::Forms::CheckedListBox());
			this->dataGridView3 = (gcnew System::Windows::Forms::DataGridView());
			this->i1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->h1i = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->xi1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Vi1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Vi11 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Vi111 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->S1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->half1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->double1 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->groupBox9 = (gcnew System::Windows::Forms::GroupBox());
			this->label64 = (gcnew System::Windows::Forms::Label());
			this->label60 = (gcnew System::Windows::Forms::Label());
			this->label59 = (gcnew System::Windows::Forms::Label());
			this->label58 = (gcnew System::Windows::Forms::Label());
			this->label57 = (gcnew System::Windows::Forms::Label());
			this->label56 = (gcnew System::Windows::Forms::Label());
			this->label55 = (gcnew System::Windows::Forms::Label());
			this->label54 = (gcnew System::Windows::Forms::Label());
			this->label53 = (gcnew System::Windows::Forms::Label());
			this->label52 = (gcnew System::Windows::Forms::Label());
			this->label51 = (gcnew System::Windows::Forms::Label());
			this->label50 = (gcnew System::Windows::Forms::Label());
			this->label49 = (gcnew System::Windows::Forms::Label());
			this->label48 = (gcnew System::Windows::Forms::Label());
			this->label47 = (gcnew System::Windows::Forms::Label());
			this->label46 = (gcnew System::Windows::Forms::Label());
			this->label45 = (gcnew System::Windows::Forms::Label());
			this->label44 = (gcnew System::Windows::Forms::Label());
			this->label43 = (gcnew System::Windows::Forms::Label());
			this->label42 = (gcnew System::Windows::Forms::Label());
			this->label41 = (gcnew System::Windows::Forms::Label());
			this->zedGraphControl3 = (gcnew ZedGraph::ZedGraphControl());
			this->groupBox7 = (gcnew System::Windows::Forms::GroupBox());
			this->label24 = (gcnew System::Windows::Forms::Label());
			this->label23 = (gcnew System::Windows::Forms::Label());
			this->label22 = (gcnew System::Windows::Forms::Label());
			this->textBox21 = (gcnew System::Windows::Forms::TextBox());
			this->textBox19 = (gcnew System::Windows::Forms::TextBox());
			this->textBox20 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox6 = (gcnew System::Windows::Forms::GroupBox());
			this->textBox18 = (gcnew System::Windows::Forms::TextBox());
			this->label20 = (gcnew System::Windows::Forms::Label());
			this->label19 = (gcnew System::Windows::Forms::Label());
			this->pictureBox2 = (gcnew System::Windows::Forms::PictureBox());
			this->tabPage3 = (gcnew System::Windows::Forms::TabPage());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->label69 = (gcnew System::Windows::Forms::Label());
			this->label68 = (gcnew System::Windows::Forms::Label());
			this->textBox16 = (gcnew System::Windows::Forms::TextBox());
			this->textBox15 = (gcnew System::Windows::Forms::TextBox());
			this->dataGridView4 = (gcnew System::Windows::Forms::DataGridView());
			this->i3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->hi3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->xi3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Vi3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->V2i3 = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->V1iii = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->V2iii = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->V1iiii = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->V2iiii = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->Siii = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->halfiii = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->doubleiii = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->zedGraphControl5 = (gcnew ZedGraph::ZedGraphControl());
			this->zedGraphControl4 = (gcnew ZedGraph::ZedGraphControl());
			this->groupBox13 = (gcnew System::Windows::Forms::GroupBox());
			this->label89 = (gcnew System::Windows::Forms::Label());
			this->label88 = (gcnew System::Windows::Forms::Label());
			this->label87 = (gcnew System::Windows::Forms::Label());
			this->label86 = (gcnew System::Windows::Forms::Label());
			this->label85 = (gcnew System::Windows::Forms::Label());
			this->label84 = (gcnew System::Windows::Forms::Label());
			this->label83 = (gcnew System::Windows::Forms::Label());
			this->label82 = (gcnew System::Windows::Forms::Label());
			this->label81 = (gcnew System::Windows::Forms::Label());
			this->label80 = (gcnew System::Windows::Forms::Label());
			this->label79 = (gcnew System::Windows::Forms::Label());
			this->label78 = (gcnew System::Windows::Forms::Label());
			this->label77 = (gcnew System::Windows::Forms::Label());
			this->label76 = (gcnew System::Windows::Forms::Label());
			this->label75 = (gcnew System::Windows::Forms::Label());
			this->label74 = (gcnew System::Windows::Forms::Label());
			this->label73 = (gcnew System::Windows::Forms::Label());
			this->label72 = (gcnew System::Windows::Forms::Label());
			this->label71 = (gcnew System::Windows::Forms::Label());
			this->label70 = (gcnew System::Windows::Forms::Label());
			this->groupBox12 = (gcnew System::Windows::Forms::GroupBox());
			this->label67 = (gcnew System::Windows::Forms::Label());
			this->checkedListBox4 = (gcnew System::Windows::Forms::CheckedListBox());
			this->textBox14 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox11 = (gcnew System::Windows::Forms::GroupBox());
			this->textBox12 = (gcnew System::Windows::Forms::TextBox());
			this->label63 = (gcnew System::Windows::Forms::Label());
			this->textBox10 = (gcnew System::Windows::Forms::TextBox());
			this->label61 = (gcnew System::Windows::Forms::Label());
			this->groupBox10 = (gcnew System::Windows::Forms::GroupBox());
			this->label66 = (gcnew System::Windows::Forms::Label());
			this->label65 = (gcnew System::Windows::Forms::Label());
			this->label62 = (gcnew System::Windows::Forms::Label());
			this->textBox13 = (gcnew System::Windows::Forms::TextBox());
			this->textBox11 = (gcnew System::Windows::Forms::TextBox());
			this->textBox6 = (gcnew System::Windows::Forms::TextBox());
			this->pictureBox3 = (gcnew System::Windows::Forms::PictureBox());
			this->label21 = (gcnew System::Windows::Forms::Label());
			this->checkedListBox2 = (gcnew System::Windows::Forms::CheckedListBox());
			this->textBox22 = (gcnew System::Windows::Forms::TextBox());
			this->tabControl1->SuspendLayout();
			this->tabPage1->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox5->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->groupBox2->SuspendLayout();
			this->groupBox1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView2))->BeginInit();
			this->tabPage2->SuspendLayout();
			this->groupBox8->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView3))->BeginInit();
			this->groupBox9->SuspendLayout();
			this->groupBox7->SuspendLayout();
			this->groupBox6->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->BeginInit();
			this->tabPage3->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView4))->BeginInit();
			this->groupBox13->SuspendLayout();
			this->groupBox12->SuspendLayout();
			this->groupBox11->SuspendLayout();
			this->groupBox10->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->BeginInit();
			this->SuspendLayout();
			// 
			// zedGraphControl2
			// 
			this->zedGraphControl2->Location = System::Drawing::Point(401, 3);
			this->zedGraphControl2->Name = L"zedGraphControl2";
			this->zedGraphControl2->ScrollGrace = 0;
			this->zedGraphControl2->ScrollMaxX = 0;
			this->zedGraphControl2->ScrollMaxY = 0;
			this->zedGraphControl2->ScrollMaxY2 = 0;
			this->zedGraphControl2->ScrollMinX = 0;
			this->zedGraphControl2->ScrollMinY = 0;
			this->zedGraphControl2->ScrollMinY2 = 0;
			this->zedGraphControl2->Size = System::Drawing::Size(882, 314);
			this->zedGraphControl2->TabIndex = 0;
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->tabPage1);
			this->tabControl1->Controls->Add(this->tabPage2);
			this->tabControl1->Controls->Add(this->tabPage3);
			this->tabControl1->Location = System::Drawing::Point(1, 3);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(1373, 588);
			this->tabControl1->TabIndex = 1;
			// 
			// tabPage1
			// 
			this->tabPage1->Controls->Add(this->groupBox4);
			this->tabPage1->Controls->Add(this->groupBox5);
			this->tabPage1->Controls->Add(this->button3);
			this->tabPage1->Controls->Add(this->button2);
			this->tabPage1->Controls->Add(this->pictureBox1);
			this->tabPage1->Controls->Add(this->groupBox2);
			this->tabPage1->Controls->Add(this->groupBox1);
			this->tabPage1->Controls->Add(this->label4);
			this->tabPage1->Controls->Add(this->dataGridView2);
			this->tabPage1->Controls->Add(this->zedGraphControl2);
			this->tabPage1->Location = System::Drawing::Point(4, 22);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(3);
			this->tabPage1->Size = System::Drawing::Size(1365, 562);
			this->tabPage1->TabIndex = 0;
			this->tabPage1->Text = L"test";
			this->tabPage1->UseVisualStyleBackColor = true;
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->checkedListBox1);
			this->groupBox4->Controls->Add(this->label9);
			this->groupBox4->Controls->Add(this->textBox8);
			this->groupBox4->Location = System::Drawing::Point(201, 73);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(192, 117);
			this->groupBox4->TabIndex = 17;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = L"��������� �������� ��:";
			// 
			// checkedListBox1
			// 
			this->checkedListBox1->FormattingEnabled = true;
			this->checkedListBox1->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"��� ��������", L"� ���������" });
			this->checkedListBox1->Location = System::Drawing::Point(11, 16);
			this->checkedListBox1->Name = L"checkedListBox1";
			this->checkedListBox1->Size = System::Drawing::Size(120, 34);
			this->checkedListBox1->TabIndex = 15;
			// 
			// label9
			// 
			this->label9->AutoSize = true;
			this->label9->Location = System::Drawing::Point(9, 59);
			this->label9->Name = L"label9";
			this->label9->Size = System::Drawing::Size(25, 13);
			this->label9->TabIndex = 13;
			this->label9->Text = L"Eps";
			// 
			// textBox8
			// 
			this->textBox8->Location = System::Drawing::Point(39, 56);
			this->textBox8->Name = L"textBox8";
			this->textBox8->Size = System::Drawing::Size(92, 20);
			this->textBox8->TabIndex = 16;
			this->textBox8->Text = L"0,0000001";
			// 
			// groupBox5
			// 
			this->groupBox5->Controls->Add(this->label40);
			this->groupBox5->Controls->Add(this->label39);
			this->groupBox5->Controls->Add(this->label38);
			this->groupBox5->Controls->Add(this->label37);
			this->groupBox5->Controls->Add(this->label36);
			this->groupBox5->Controls->Add(this->label35);
			this->groupBox5->Controls->Add(this->label34);
			this->groupBox5->Controls->Add(this->label33);
			this->groupBox5->Controls->Add(this->label32);
			this->groupBox5->Controls->Add(this->label31);
			this->groupBox5->Controls->Add(this->label30);
			this->groupBox5->Controls->Add(this->label29);
			this->groupBox5->Controls->Add(this->label28);
			this->groupBox5->Controls->Add(this->label27);
			this->groupBox5->Controls->Add(this->label26);
			this->groupBox5->Controls->Add(this->label18);
			this->groupBox5->Controls->Add(this->label17);
			this->groupBox5->Controls->Add(this->label16);
			this->groupBox5->Controls->Add(this->label15);
			this->groupBox5->Controls->Add(this->label14);
			this->groupBox5->Controls->Add(this->label13);
			this->groupBox5->Controls->Add(this->label12);
			this->groupBox5->Controls->Add(this->label11);
			this->groupBox5->Controls->Add(this->label7);
			this->groupBox5->Location = System::Drawing::Point(7, 323);
			this->groupBox5->Name = L"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(386, 239);
			this->groupBox5->TabIndex = 15;
			this->groupBox5->TabStop = false;
			this->groupBox5->Text = L"�������:";
			// 
			// label40
			// 
			this->label40->AutoSize = true;
			this->label40->Location = System::Drawing::Point(204, 178);
			this->label40->Name = L"label40";
			this->label40->Size = System::Drawing::Size(13, 13);
			this->label40->TabIndex = 32;
			this->label40->Text = L"0";
			// 
			// label39
			// 
			this->label39->AutoSize = true;
			this->label39->Location = System::Drawing::Point(2, 178);
			this->label39->Name = L"label39";
			this->label39->Size = System::Drawing::Size(145, 13);
			this->label39->TabIndex = 31;
			this->label39->Text = L"����� ����� ������� ����";
			// 
			// label38
			// 
			this->label38->AutoSize = true;
			this->label38->Location = System::Drawing::Point(204, 151);
			this->label38->Name = L"label38";
			this->label38->Size = System::Drawing::Size(13, 13);
			this->label38->TabIndex = 30;
			this->label38->Text = L"0";
			// 
			// label37
			// 
			this->label37->AutoSize = true;
			this->label37->Location = System::Drawing::Point(2, 151);
			this->label37->Name = L"label37";
			this->label37->Size = System::Drawing::Size(160, 13);
			this->label37->TabIndex = 29;
			this->label37->Text = L"����� ����� ��������� ����";
			// 
			// label36
			// 
			this->label36->AutoSize = true;
			this->label36->Location = System::Drawing::Point(250, 203);
			this->label36->Name = L"label36";
			this->label36->Size = System::Drawing::Size(13, 13);
			this->label36->TabIndex = 28;
			this->label36->Text = L"0";
			// 
			// label35
			// 
			this->label35->AutoSize = true;
			this->label35->Location = System::Drawing::Point(55, 203);
			this->label35->Name = L"label35";
			this->label35->Size = System::Drawing::Size(13, 13);
			this->label35->TabIndex = 27;
			this->label35->Text = L"0";
			// 
			// label34
			// 
			this->label34->AutoSize = true;
			this->label34->Location = System::Drawing::Point(251, 74);
			this->label34->Name = L"label34";
			this->label34->Size = System::Drawing::Size(13, 13);
			this->label34->TabIndex = 26;
			this->label34->Text = L"0";
			// 
			// label33
			// 
			this->label33->AutoSize = true;
			this->label33->Location = System::Drawing::Point(203, 74);
			this->label33->Name = L"label33";
			this->label33->Size = System::Drawing::Size(42, 13);
			this->label33->TabIndex = 25;
			this->label33->Text = L"��� x =";
			// 
			// label32
			// 
			this->label32->AutoSize = true;
			this->label32->Location = System::Drawing::Point(250, 127);
			this->label32->Name = L"label32";
			this->label32->Size = System::Drawing::Size(13, 13);
			this->label32->TabIndex = 24;
			this->label32->Text = L"0";
			// 
			// label31
			// 
			this->label31->AutoSize = true;
			this->label31->Location = System::Drawing::Point(42, 127);
			this->label31->Name = L"label31";
			this->label31->Size = System::Drawing::Size(13, 13);
			this->label31->TabIndex = 23;
			this->label31->Text = L"0";
			// 
			// label30
			// 
			this->label30->AutoSize = true;
			this->label30->Location = System::Drawing::Point(250, 102);
			this->label30->Name = L"label30";
			this->label30->Size = System::Drawing::Size(13, 13);
			this->label30->TabIndex = 22;
			this->label30->Text = L"0";
			// 
			// label29
			// 
			this->label29->AutoSize = true;
			this->label29->Location = System::Drawing::Point(42, 102);
			this->label29->Name = L"label29";
			this->label29->Size = System::Drawing::Size(13, 13);
			this->label29->TabIndex = 21;
			this->label29->Text = L"0";
			// 
			// label28
			// 
			this->label28->AutoSize = true;
			this->label28->Location = System::Drawing::Point(71, 74);
			this->label28->Name = L"label28";
			this->label28->Size = System::Drawing::Size(13, 13);
			this->label28->TabIndex = 20;
			this->label28->Text = L"0";
			// 
			// label27
			// 
			this->label27->AutoSize = true;
			this->label27->Location = System::Drawing::Point(47, 45);
			this->label27->Name = L"label27";
			this->label27->Size = System::Drawing::Size(13, 13);
			this->label27->TabIndex = 19;
			this->label27->Text = L"0";
			// 
			// label26
			// 
			this->label26->AutoSize = true;
			this->label26->Location = System::Drawing::Point(25, 19);
			this->label26->Name = L"label26";
			this->label26->Size = System::Drawing::Size(13, 13);
			this->label26->TabIndex = 18;
			this->label26->Text = L"0";
			// 
			// label18
			// 
			this->label18->AutoSize = true;
			this->label18->Location = System::Drawing::Point(203, 127);
			this->label18->Name = L"label18";
			this->label18->Size = System::Drawing::Size(42, 13);
			this->label18->TabIndex = 17;
			this->label18->Text = L"��� x =";
			// 
			// label17
			// 
			this->label17->AutoSize = true;
			this->label17->Location = System::Drawing::Point(202, 102);
			this->label17->Name = L"label17";
			this->label17->Size = System::Drawing::Size(42, 13);
			this->label17->TabIndex = 16;
			this->label17->Text = L"��� x =";
			// 
			// label16
			// 
			this->label16->AutoSize = true;
			this->label16->Location = System::Drawing::Point(2, 127);
			this->label16->Name = L"label16";
			this->label16->Size = System::Drawing::Size(31, 13);
			this->label16->TabIndex = 10;
			this->label16->Text = L"minhi";
			// 
			// label15
			// 
			this->label15->AutoSize = true;
			this->label15->Location = System::Drawing::Point(2, 102);
			this->label15->Name = L"label15";
			this->label15->Size = System::Drawing::Size(34, 13);
			this->label15->TabIndex = 9;
			this->label15->Text = L"maxhi";
			// 
			// label14
			// 
			this->label14->AutoSize = true;
			this->label14->Location = System::Drawing::Point(2, 74);
			this->label14->Name = L"label14";
			this->label14->Size = System::Drawing::Size(63, 13);
			this->label14->TabIndex = 8;
			this->label14->Text = L"max | ��� |";
			// 
			// label13
			// 
			this->label13->AutoSize = true;
			this->label13->Location = System::Drawing::Point(6, 45);
			this->label13->Name = L"label13";
			this->label13->Size = System::Drawing::Size(33, 13);
			this->label13->TabIndex = 7;
			this->label13->Text = L"b - xn";
			// 
			// label12
			// 
			this->label12->AutoSize = true;
			this->label12->Location = System::Drawing::Point(6, 19);
			this->label12->Name = L"label12";
			this->label12->Size = System::Drawing::Size(13, 13);
			this->label12->TabIndex = 6;
			this->label12->Text = L"n";
			// 
			// label11
			// 
			this->label11->AutoSize = true;
			this->label11->Location = System::Drawing::Point(202, 203);
			this->label11->Name = L"label11";
			this->label11->Size = System::Drawing::Size(42, 13);
			this->label11->TabIndex = 5;
			this->label11->Text = L"��� x =";
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(2, 203);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(47, 13);
			this->label7->TabIndex = 1;
			this->label7->Text = L"max | ui |";
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(201, 230);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(192, 87);
			this->button3->TabIndex = 14;
			this->button3->Text = L"��������";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &MyForm::button3_Click_1);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(0, 230);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(195, 87);
			this->button2->TabIndex = 0;
			this->button2->Text = L"������";
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox1.Image")));
			this->pictureBox1->Location = System::Drawing::Point(3, 17);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(100, 50);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox1->TabIndex = 13;
			this->pictureBox1->TabStop = false;
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->groupBox3);
			this->groupBox2->Controls->Add(this->textBox7);
			this->groupBox2->Controls->Add(this->label8);
			this->groupBox2->Location = System::Drawing::Point(122, 14);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(192, 53);
			this->groupBox2->TabIndex = 10;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"��������� �������:";
			// 
			// groupBox3
			// 
			this->groupBox3->Location = System::Drawing::Point(0, 56);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(192, 100);
			this->groupBox3->TabIndex = 12;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"�������� ��������� �����������:";
			// 
			// textBox7
			// 
			this->textBox7->Location = System::Drawing::Point(46, 21);
			this->textBox7->Name = L"textBox7";
			this->textBox7->Size = System::Drawing::Size(61, 20);
			this->textBox7->TabIndex = 1;
			this->textBox7->Text = L"3";
			// 
			// label8
			// 
			this->label8->AutoSize = true;
			this->label8->Location = System::Drawing::Point(6, 24);
			this->label8->Name = L"label8";
			this->label8->Size = System::Drawing::Size(34, 13);
			this->label8->TabIndex = 0;
			this->label8->Text = L"u(0) =";
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label10);
			this->groupBox1->Controls->Add(this->textBox9);
			this->groupBox1->Controls->Add(this->textBox4);
			this->groupBox1->Controls->Add(this->label5);
			this->groupBox1->Controls->Add(this->label6);
			this->groupBox1->Controls->Add(this->textBox5);
			this->groupBox1->Location = System::Drawing::Point(3, 68);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(192, 122);
			this->groupBox1->TabIndex = 9;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"��������� ������:";
			// 
			// label10
			// 
			this->label10->AutoSize = true;
			this->label10->Location = System::Drawing::Point(6, 19);
			this->label10->Name = L"label10";
			this->label10->Size = System::Drawing::Size(86, 13);
			this->label10->TabIndex = 10;
			this->label10->Text = L"��������� ���";
			// 
			// textBox9
			// 
			this->textBox9->Location = System::Drawing::Point(98, 16);
			this->textBox9->Name = L"textBox9";
			this->textBox9->Size = System::Drawing::Size(52, 20);
			this->textBox9->TabIndex = 9;
			this->textBox9->Text = L"0,01";
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(49, 39);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(51, 20);
			this->textBox4->TabIndex = 4;
			this->textBox4->Text = L"50";
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(6, 42);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(37, 13);
			this->label5->TabIndex = 3;
			this->label5->Text = L"N max";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(3, 68);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(104, 13);
			this->label6->TabIndex = 7;
			this->label6->Text = L"������ ������� (b)";
			// 
			// textBox5
			// 
			this->textBox5->Location = System::Drawing::Point(108, 64);
			this->textBox5->Name = L"textBox5";
			this->textBox5->Size = System::Drawing::Size(51, 20);
			this->textBox5->TabIndex = 5;
			this->textBox5->Text = L"5";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(3, 3);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(115, 13);
			this->label4->TabIndex = 2;
			this->label4->Text = L"�������� ���������:";
			// 
			// dataGridView2
			// 
			this->dataGridView2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView2->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(11) {
				this->i, this->hi,
					this->xi, this->vi, this->v2i, this->viv2i, this->OLP, this->halfh, this->doubleh, this->ui, this->uivi
			});
			this->dataGridView2->Location = System::Drawing::Point(401, 323);
			this->dataGridView2->Name = L"dataGridView2";
			this->dataGridView2->Size = System::Drawing::Size(882, 236);
			this->dataGridView2->TabIndex = 1;
			// 
			// i
			// 
			this->i->HeaderText = L"i";
			this->i->Name = L"i";
			// 
			// hi
			// 
			this->hi->HeaderText = L"hi";
			this->hi->Name = L"hi";
			// 
			// xi
			// 
			this->xi->HeaderText = L"Xi";
			this->xi->Name = L"xi";
			// 
			// vi
			// 
			this->vi->HeaderText = L"Vi";
			this->vi->Name = L"vi";
			// 
			// v2i
			// 
			this->v2i->HeaderText = L"V2i";
			this->v2i->Name = L"v2i";
			// 
			// viv2i
			// 
			this->viv2i->HeaderText = L"Vi - V2i";
			this->viv2i->Name = L"viv2i";
			// 
			// OLP
			// 
			this->OLP->HeaderText = L"���";
			this->OLP->Name = L"OLP";
			// 
			// halfh
			// 
			this->halfh->HeaderText = L"������� ����";
			this->halfh->Name = L"halfh";
			// 
			// doubleh
			// 
			this->doubleh->HeaderText = L"��������� ����";
			this->doubleh->Name = L"doubleh";
			// 
			// ui
			// 
			this->ui->HeaderText = L"ui";
			this->ui->Name = L"ui";
			// 
			// uivi
			// 
			this->uivi->HeaderText = L"| ui - Vi |";
			this->uivi->Name = L"uivi";
			// 
			// tabPage2
			// 
			this->tabPage2->Controls->Add(this->groupBox8);
			this->tabPage2->Controls->Add(this->dataGridView3);
			this->tabPage2->Controls->Add(this->button5);
			this->tabPage2->Controls->Add(this->button4);
			this->tabPage2->Controls->Add(this->groupBox9);
			this->tabPage2->Controls->Add(this->zedGraphControl3);
			this->tabPage2->Controls->Add(this->groupBox7);
			this->tabPage2->Controls->Add(this->groupBox6);
			this->tabPage2->Controls->Add(this->label19);
			this->tabPage2->Controls->Add(this->pictureBox2);
			this->tabPage2->Location = System::Drawing::Point(4, 22);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Padding = System::Windows::Forms::Padding(3);
			this->tabPage2->Size = System::Drawing::Size(1365, 562);
			this->tabPage2->TabIndex = 1;
			this->tabPage2->Text = L"base 1";
			this->tabPage2->UseVisualStyleBackColor = true;
			// 
			// groupBox8
			// 
			this->groupBox8->Controls->Add(this->textBox23);
			this->groupBox8->Controls->Add(this->label25);
			this->groupBox8->Controls->Add(this->checkedListBox3);
			this->groupBox8->Location = System::Drawing::Point(196, 83);
			this->groupBox8->Name = L"groupBox8";
			this->groupBox8->Size = System::Drawing::Size(190, 100);
			this->groupBox8->TabIndex = 11;
			this->groupBox8->TabStop = false;
			this->groupBox8->Text = L"��������� �������� ��:";
			// 
			// textBox23
			// 
			this->textBox23->Location = System::Drawing::Point(48, 68);
			this->textBox23->Name = L"textBox23";
			this->textBox23->Size = System::Drawing::Size(91, 20);
			this->textBox23->TabIndex = 2;
			this->textBox23->Text = L"0,0000001";
			// 
			// label25
			// 
			this->label25->AutoSize = true;
			this->label25->Location = System::Drawing::Point(16, 71);
			this->label25->Name = L"label25";
			this->label25->Size = System::Drawing::Size(25, 13);
			this->label25->TabIndex = 1;
			this->label25->Text = L"Eps";
			// 
			// checkedListBox3
			// 
			this->checkedListBox3->FormattingEnabled = true;
			this->checkedListBox3->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"��� ��������", L"� ���������" });
			this->checkedListBox3->Location = System::Drawing::Point(19, 14);
			this->checkedListBox3->Name = L"checkedListBox3";
			this->checkedListBox3->Size = System::Drawing::Size(120, 49);
			this->checkedListBox3->TabIndex = 0;
			// 
			// dataGridView3
			// 
			this->dataGridView3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView3->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(9) {
				this->i1, this->h1i,
					this->xi1, this->Vi1, this->Vi11, this->Vi111, this->S1, this->half1, this->double1
			});
			this->dataGridView3->Location = System::Drawing::Point(392, 326);
			this->dataGridView3->Name = L"dataGridView3";
			this->dataGridView3->Size = System::Drawing::Size(967, 227);
			this->dataGridView3->TabIndex = 10;
			// 
			// i1
			// 
			this->i1->HeaderText = L"i";
			this->i1->Name = L"i1";
			// 
			// h1i
			// 
			this->h1i->HeaderText = L"hi";
			this->h1i->Name = L"h1i";
			// 
			// xi1
			// 
			this->xi1->HeaderText = L"Xi";
			this->xi1->Name = L"xi1";
			// 
			// Vi1
			// 
			this->Vi1->HeaderText = L"Vi";
			this->Vi1->Name = L"Vi1";
			// 
			// Vi11
			// 
			this->Vi11->HeaderText = L"V2i ";
			this->Vi11->Name = L"Vi11";
			// 
			// Vi111
			// 
			this->Vi111->HeaderText = L" Vi - V2i ";
			this->Vi111->Name = L"Vi111";
			// 
			// S1
			// 
			this->S1->HeaderText = L"���";
			this->S1->Name = L"S1";
			// 
			// half1
			// 
			this->half1->HeaderText = L"������� ����";
			this->half1->Name = L"half1";
			// 
			// double1
			// 
			this->double1->HeaderText = L"��������� ����";
			this->double1->Name = L"double1";
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(196, 237);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(190, 83);
			this->button5->TabIndex = 9;
			this->button5->Text = L"��������";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &MyForm::button5_Click_1);
			// 
			// button4
			// 
			this->button4->Location = System::Drawing::Point(10, 237);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(180, 83);
			this->button4->TabIndex = 8;
			this->button4->Text = L"������";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &MyForm::button4_Click);
			// 
			// groupBox9
			// 
			this->groupBox9->Controls->Add(this->label64);
			this->groupBox9->Controls->Add(this->label60);
			this->groupBox9->Controls->Add(this->label59);
			this->groupBox9->Controls->Add(this->label58);
			this->groupBox9->Controls->Add(this->label57);
			this->groupBox9->Controls->Add(this->label56);
			this->groupBox9->Controls->Add(this->label55);
			this->groupBox9->Controls->Add(this->label54);
			this->groupBox9->Controls->Add(this->label53);
			this->groupBox9->Controls->Add(this->label52);
			this->groupBox9->Controls->Add(this->label51);
			this->groupBox9->Controls->Add(this->label50);
			this->groupBox9->Controls->Add(this->label49);
			this->groupBox9->Controls->Add(this->label48);
			this->groupBox9->Controls->Add(this->label47);
			this->groupBox9->Controls->Add(this->label46);
			this->groupBox9->Controls->Add(this->label45);
			this->groupBox9->Controls->Add(this->label44);
			this->groupBox9->Controls->Add(this->label43);
			this->groupBox9->Controls->Add(this->label42);
			this->groupBox9->Controls->Add(this->label41);
			this->groupBox9->Location = System::Drawing::Point(6, 326);
			this->groupBox9->Name = L"groupBox9";
			this->groupBox9->Size = System::Drawing::Size(380, 227);
			this->groupBox9->TabIndex = 7;
			this->groupBox9->TabStop = false;
			this->groupBox9->Text = L"�������:";
			// 
			// label64
			// 
			this->label64->AutoSize = true;
			this->label64->Location = System::Drawing::Point(162, 195);
			this->label64->Name = L"label64";
			this->label64->Size = System::Drawing::Size(13, 13);
			this->label64->TabIndex = 23;
			this->label64->Text = L"0";
			// 
			// label60
			// 
			this->label60->AutoSize = true;
			this->label60->Location = System::Drawing::Point(6, 195);
			this->label60->Name = L"label60";
			this->label60->Size = System::Drawing::Size(145, 13);
			this->label60->TabIndex = 19;
			this->label60->Text = L"����� ����� ������� ����";
			// 
			// label59
			// 
			this->label59->AutoSize = true;
			this->label59->Location = System::Drawing::Point(162, 170);
			this->label59->Name = L"label59";
			this->label59->Size = System::Drawing::Size(13, 13);
			this->label59->TabIndex = 18;
			this->label59->Text = L"0";
			// 
			// label58
			// 
			this->label58->AutoSize = true;
			this->label58->Location = System::Drawing::Point(6, 170);
			this->label58->Name = L"label58";
			this->label58->Size = System::Drawing::Size(150, 13);
			this->label58->TabIndex = 17;
			this->label58->Text = L"����� ����� �������� ����";
			// 
			// label57
			// 
			this->label57->AutoSize = true;
			this->label57->Location = System::Drawing::Point(6, 171);
			this->label57->Name = L"label57";
			this->label57->Size = System::Drawing::Size(0, 13);
			this->label57->TabIndex = 16;
			// 
			// label56
			// 
			this->label56->AutoSize = true;
			this->label56->Location = System::Drawing::Point(255, 143);
			this->label56->Name = L"label56";
			this->label56->Size = System::Drawing::Size(13, 13);
			this->label56->TabIndex = 15;
			this->label56->Text = L"0";
			// 
			// label55
			// 
			this->label55->AutoSize = true;
			this->label55->Location = System::Drawing::Point(206, 143);
			this->label55->Name = L"label55";
			this->label55->Size = System::Drawing::Size(42, 13);
			this->label55->TabIndex = 14;
			this->label55->Text = L"��� x =";
			// 
			// label54
			// 
			this->label54->AutoSize = true;
			this->label54->Location = System::Drawing::Point(72, 143);
			this->label54->Name = L"label54";
			this->label54->Size = System::Drawing::Size(13, 13);
			this->label54->TabIndex = 13;
			this->label54->Text = L"0";
			// 
			// label53
			// 
			this->label53->AutoSize = true;
			this->label53->Location = System::Drawing::Point(6, 144);
			this->label53->Name = L"label53";
			this->label53->Size = System::Drawing::Size(34, 13);
			this->label53->TabIndex = 12;
			this->label53->Text = L"min hi";
			// 
			// label52
			// 
			this->label52->AutoSize = true;
			this->label52->Location = System::Drawing::Point(255, 115);
			this->label52->Name = L"label52";
			this->label52->Size = System::Drawing::Size(13, 13);
			this->label52->TabIndex = 11;
			this->label52->Text = L"0";
			// 
			// label51
			// 
			this->label51->AutoSize = true;
			this->label51->Location = System::Drawing::Point(206, 115);
			this->label51->Name = L"label51";
			this->label51->Size = System::Drawing::Size(42, 13);
			this->label51->TabIndex = 10;
			this->label51->Text = L"��� x =";
			// 
			// label50
			// 
			this->label50->AutoSize = true;
			this->label50->Location = System::Drawing::Point(72, 115);
			this->label50->Name = L"label50";
			this->label50->Size = System::Drawing::Size(13, 13);
			this->label50->TabIndex = 9;
			this->label50->Text = L"0";
			// 
			// label49
			// 
			this->label49->AutoSize = true;
			this->label49->Location = System::Drawing::Point(7, 115);
			this->label49->Name = L"label49";
			this->label49->Size = System::Drawing::Size(37, 13);
			this->label49->TabIndex = 8;
			this->label49->Text = L"max hi";
			// 
			// label48
			// 
			this->label48->AutoSize = true;
			this->label48->Location = System::Drawing::Point(254, 88);
			this->label48->Name = L"label48";
			this->label48->Size = System::Drawing::Size(13, 13);
			this->label48->TabIndex = 7;
			this->label48->Text = L"0";
			// 
			// label47
			// 
			this->label47->AutoSize = true;
			this->label47->Location = System::Drawing::Point(206, 88);
			this->label47->Name = L"label47";
			this->label47->Size = System::Drawing::Size(42, 13);
			this->label47->TabIndex = 6;
			this->label47->Text = L"��� � =";
			// 
			// label46
			// 
			this->label46->AutoSize = true;
			this->label46->Location = System::Drawing::Point(72, 88);
			this->label46->Name = L"label46";
			this->label46->Size = System::Drawing::Size(13, 13);
			this->label46->TabIndex = 5;
			this->label46->Text = L"0";
			// 
			// label45
			// 
			this->label45->AutoSize = true;
			this->label45->Location = System::Drawing::Point(7, 88);
			this->label45->Name = L"label45";
			this->label45->Size = System::Drawing::Size(63, 13);
			this->label45->TabIndex = 4;
			this->label45->Text = L"max | ��� |";
			// 
			// label44
			// 
			this->label44->AutoSize = true;
			this->label44->Location = System::Drawing::Point(45, 61);
			this->label44->Name = L"label44";
			this->label44->Size = System::Drawing::Size(13, 13);
			this->label44->TabIndex = 3;
			this->label44->Text = L"0";
			// 
			// label43
			// 
			this->label43->AutoSize = true;
			this->label43->Location = System::Drawing::Point(6, 61);
			this->label43->Name = L"label43";
			this->label43->Size = System::Drawing::Size(33, 13);
			this->label43->TabIndex = 2;
			this->label43->Text = L"b - xn";
			// 
			// label42
			// 
			this->label42->AutoSize = true;
			this->label42->Location = System::Drawing::Point(28, 31);
			this->label42->Name = L"label42";
			this->label42->Size = System::Drawing::Size(13, 13);
			this->label42->TabIndex = 1;
			this->label42->Text = L"0";
			// 
			// label41
			// 
			this->label41->AutoSize = true;
			this->label41->Location = System::Drawing::Point(9, 31);
			this->label41->Name = L"label41";
			this->label41->Size = System::Drawing::Size(13, 13);
			this->label41->TabIndex = 0;
			this->label41->Text = L"n";
			// 
			// zedGraphControl3
			// 
			this->zedGraphControl3->Location = System::Drawing::Point(392, 6);
			this->zedGraphControl3->Name = L"zedGraphControl3";
			this->zedGraphControl3->ScrollGrace = 0;
			this->zedGraphControl3->ScrollMaxX = 0;
			this->zedGraphControl3->ScrollMaxY = 0;
			this->zedGraphControl3->ScrollMaxY2 = 0;
			this->zedGraphControl3->ScrollMinX = 0;
			this->zedGraphControl3->ScrollMinY = 0;
			this->zedGraphControl3->ScrollMinY2 = 0;
			this->zedGraphControl3->Size = System::Drawing::Size(967, 314);
			this->zedGraphControl3->TabIndex = 6;
			// 
			// groupBox7
			// 
			this->groupBox7->Controls->Add(this->label24);
			this->groupBox7->Controls->Add(this->label23);
			this->groupBox7->Controls->Add(this->label22);
			this->groupBox7->Controls->Add(this->textBox21);
			this->groupBox7->Controls->Add(this->textBox19);
			this->groupBox7->Controls->Add(this->textBox20);
			this->groupBox7->Location = System::Drawing::Point(6, 83);
			this->groupBox7->Name = L"groupBox7";
			this->groupBox7->Size = System::Drawing::Size(184, 100);
			this->groupBox7->TabIndex = 4;
			this->groupBox7->TabStop = false;
			this->groupBox7->Text = L"��������� ������:";
			// 
			// label24
			// 
			this->label24->AutoSize = true;
			this->label24->Location = System::Drawing::Point(6, 71);
			this->label24->Name = L"label24";
			this->label24->Size = System::Drawing::Size(104, 13);
			this->label24->TabIndex = 4;
			this->label24->Text = L"������ ������� (b)";
			// 
			// label23
			// 
			this->label23->AutoSize = true;
			this->label23->Location = System::Drawing::Point(6, 46);
			this->label23->Name = L"label23";
			this->label23->Size = System::Drawing::Size(37, 13);
			this->label23->TabIndex = 3;
			this->label23->Text = L"N max";
			// 
			// label22
			// 
			this->label22->AutoSize = true;
			this->label22->Location = System::Drawing::Point(6, 23);
			this->label22->Name = L"label22";
			this->label22->Size = System::Drawing::Size(86, 13);
			this->label22->TabIndex = 2;
			this->label22->Text = L"��������� ���";
			// 
			// textBox21
			// 
			this->textBox21->Location = System::Drawing::Point(49, 43);
			this->textBox21->Name = L"textBox21";
			this->textBox21->Size = System::Drawing::Size(68, 20);
			this->textBox21->TabIndex = 1;
			this->textBox21->Text = L"40";
			// 
			// textBox19
			// 
			this->textBox19->Location = System::Drawing::Point(110, 68);
			this->textBox19->Name = L"textBox19";
			this->textBox19->Size = System::Drawing::Size(68, 20);
			this->textBox19->TabIndex = 0;
			this->textBox19->Text = L"5";
			// 
			// textBox20
			// 
			this->textBox20->Location = System::Drawing::Point(98, 20);
			this->textBox20->Name = L"textBox20";
			this->textBox20->Size = System::Drawing::Size(68, 20);
			this->textBox20->TabIndex = 0;
			this->textBox20->Text = L"0,01";
			// 
			// groupBox6
			// 
			this->groupBox6->Controls->Add(this->textBox18);
			this->groupBox6->Controls->Add(this->label20);
			this->groupBox6->Location = System::Drawing::Point(196, 3);
			this->groupBox6->Name = L"groupBox6";
			this->groupBox6->Size = System::Drawing::Size(190, 74);
			this->groupBox6->TabIndex = 3;
			this->groupBox6->TabStop = false;
			this->groupBox6->Text = L"��������� �������:";
			// 
			// textBox18
			// 
			this->textBox18->Location = System::Drawing::Point(46, 25);
			this->textBox18->Name = L"textBox18";
			this->textBox18->Size = System::Drawing::Size(69, 20);
			this->textBox18->TabIndex = 0;
			this->textBox18->Text = L"5";
			// 
			// label20
			// 
			this->label20->AutoSize = true;
			this->label20->Location = System::Drawing::Point(6, 28);
			this->label20->Name = L"label20";
			this->label20->Size = System::Drawing::Size(34, 13);
			this->label20->TabIndex = 2;
			this->label20->Text = L"u(0) =";
			// 
			// label19
			// 
			this->label19->AutoSize = true;
			this->label19->Location = System::Drawing::Point(7, 3);
			this->label19->Name = L"label19";
			this->label19->Size = System::Drawing::Size(115, 13);
			this->label19->TabIndex = 1;
			this->label19->Text = L"�������� ���������:";
			// 
			// pictureBox2
			// 
			this->pictureBox2->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox2.Image")));
			this->pictureBox2->Location = System::Drawing::Point(3, 19);
			this->pictureBox2->Name = L"pictureBox2";
			this->pictureBox2->Size = System::Drawing::Size(181, 58);
			this->pictureBox2->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox2->TabIndex = 0;
			this->pictureBox2->TabStop = false;
			// 
			// tabPage3
			// 
			this->tabPage3->Controls->Add(this->checkBox1);
			this->tabPage3->Controls->Add(this->label69);
			this->tabPage3->Controls->Add(this->label68);
			this->tabPage3->Controls->Add(this->textBox16);
			this->tabPage3->Controls->Add(this->textBox15);
			this->tabPage3->Controls->Add(this->dataGridView4);
			this->tabPage3->Controls->Add(this->button7);
			this->tabPage3->Controls->Add(this->button6);
			this->tabPage3->Controls->Add(this->zedGraphControl5);
			this->tabPage3->Controls->Add(this->zedGraphControl4);
			this->tabPage3->Controls->Add(this->groupBox13);
			this->tabPage3->Controls->Add(this->groupBox12);
			this->tabPage3->Controls->Add(this->groupBox11);
			this->tabPage3->Controls->Add(this->groupBox10);
			this->tabPage3->Controls->Add(this->pictureBox3);
			this->tabPage3->Location = System::Drawing::Point(4, 22);
			this->tabPage3->Name = L"tabPage3";
			this->tabPage3->Padding = System::Windows::Forms::Padding(3);
			this->tabPage3->Size = System::Drawing::Size(1365, 562);
			this->tabPage3->TabIndex = 2;
			this->tabPage3->Text = L"base 2";
			this->tabPage3->UseVisualStyleBackColor = true;
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Location = System::Drawing::Point(209, 316);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(116, 17);
			this->checkBox1->TabIndex = 3;
			this->checkBox1->Text = L"�������� �������";
			this->checkBox1->UseVisualStyleBackColor = true;
			// 
			// label69
			// 
			this->label69->AutoSize = true;
			this->label69->Location = System::Drawing::Point(110, 64);
			this->label69->Name = L"label69";
			this->label69->Size = System::Drawing::Size(13, 13);
			this->label69->TabIndex = 14;
			this->label69->Text = L"b";
			// 
			// label68
			// 
			this->label68->AutoSize = true;
			this->label68->Location = System::Drawing::Point(10, 64);
			this->label68->Name = L"label68";
			this->label68->Size = System::Drawing::Size(13, 13);
			this->label68->TabIndex = 13;
			this->label68->Text = L"�";
			// 
			// textBox16
			// 
			this->textBox16->Location = System::Drawing::Point(129, 61);
			this->textBox16->Name = L"textBox16";
			this->textBox16->Size = System::Drawing::Size(45, 20);
			this->textBox16->TabIndex = 12;
			this->textBox16->Text = L"10";
			// 
			// textBox15
			// 
			this->textBox15->Location = System::Drawing::Point(29, 61);
			this->textBox15->Name = L"textBox15";
			this->textBox15->Size = System::Drawing::Size(45, 20);
			this->textBox15->TabIndex = 11;
			this->textBox15->Text = L"0";
			// 
			// dataGridView4
			// 
			this->dataGridView4->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView4->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(12) {
				this->i3, this->hi3,
					this->xi3, this->Vi3, this->V2i3, this->V1iii, this->V2iii, this->V1iiii, this->V2iiii, this->Siii, this->halfiii, this->doubleiii
			});
			this->dataGridView4->Location = System::Drawing::Point(414, 360);
			this->dataGridView4->Name = L"dataGridView4";
			this->dataGridView4->Size = System::Drawing::Size(836, 196);
			this->dataGridView4->TabIndex = 10;
			// 
			// i3
			// 
			this->i3->HeaderText = L"i";
			this->i3->Name = L"i3";
			// 
			// hi3
			// 
			this->hi3->HeaderText = L"hi";
			this->hi3->Name = L"hi3";
			// 
			// xi3
			// 
			this->xi3->HeaderText = L"Xi";
			this->xi3->Name = L"xi3";
			// 
			// Vi3
			// 
			this->Vi3->HeaderText = L"V1i";
			this->Vi3->Name = L"Vi3";
			// 
			// V2i3
			// 
			this->V2i3->HeaderText = L"V2i";
			this->V2i3->Name = L"V2i3";
			// 
			// V1iii
			// 
			this->V1iii->HeaderText = L"V1i ���";
			this->V1iii->Name = L"V1iii";
			// 
			// V2iii
			// 
			this->V2iii->HeaderText = L"V2i ���";
			this->V2iii->Name = L"V2iii";
			// 
			// V1iiii
			// 
			this->V1iiii->HeaderText = L"V1i - V1i ���";
			this->V1iiii->Name = L"V1iiii";
			// 
			// V2iiii
			// 
			this->V2iiii->HeaderText = L"V2i - V2i ���";
			this->V2iiii->Name = L"V2iiii";
			// 
			// Siii
			// 
			this->Siii->HeaderText = L"���";
			this->Siii->Name = L"Siii";
			// 
			// halfiii
			// 
			this->halfiii->HeaderText = L"������� ����";
			this->halfiii->Name = L"halfiii";
			// 
			// doubleiii
			// 
			this->doubleiii->HeaderText = L"��������� ����";
			this->doubleiii->Name = L"doubleiii";
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(781, 316);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(163, 33);
			this->button7->TabIndex = 9;
			this->button7->Text = L"��������";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &MyForm::button7_Click);
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(614, 316);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(161, 33);
			this->button6->TabIndex = 5;
			this->button6->Text = L"������";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &MyForm::button6_Click);
			// 
			// zedGraphControl5
			// 
			this->zedGraphControl5->Location = System::Drawing::Point(729, 3);
			this->zedGraphControl5->Name = L"zedGraphControl5";
			this->zedGraphControl5->ScrollGrace = 0;
			this->zedGraphControl5->ScrollMaxX = 0;
			this->zedGraphControl5->ScrollMaxY = 0;
			this->zedGraphControl5->ScrollMaxY2 = 0;
			this->zedGraphControl5->ScrollMinX = 0;
			this->zedGraphControl5->ScrollMinY = 0;
			this->zedGraphControl5->ScrollMinY2 = 0;
			this->zedGraphControl5->Size = System::Drawing::Size(521, 307);
			this->zedGraphControl5->TabIndex = 8;
			// 
			// zedGraphControl4
			// 
			this->zedGraphControl4->Location = System::Drawing::Point(209, 3);
			this->zedGraphControl4->Name = L"zedGraphControl4";
			this->zedGraphControl4->ScrollGrace = 0;
			this->zedGraphControl4->ScrollMaxX = 0;
			this->zedGraphControl4->ScrollMaxY = 0;
			this->zedGraphControl4->ScrollMaxY2 = 0;
			this->zedGraphControl4->ScrollMinX = 0;
			this->zedGraphControl4->ScrollMinY = 0;
			this->zedGraphControl4->ScrollMinY2 = 0;
			this->zedGraphControl4->Size = System::Drawing::Size(514, 307);
			this->zedGraphControl4->TabIndex = 7;
			// 
			// groupBox13
			// 
			this->groupBox13->Controls->Add(this->label89);
			this->groupBox13->Controls->Add(this->label88);
			this->groupBox13->Controls->Add(this->label87);
			this->groupBox13->Controls->Add(this->label86);
			this->groupBox13->Controls->Add(this->label85);
			this->groupBox13->Controls->Add(this->label84);
			this->groupBox13->Controls->Add(this->label83);
			this->groupBox13->Controls->Add(this->label82);
			this->groupBox13->Controls->Add(this->label81);
			this->groupBox13->Controls->Add(this->label80);
			this->groupBox13->Controls->Add(this->label79);
			this->groupBox13->Controls->Add(this->label78);
			this->groupBox13->Controls->Add(this->label77);
			this->groupBox13->Controls->Add(this->label76);
			this->groupBox13->Controls->Add(this->label75);
			this->groupBox13->Controls->Add(this->label74);
			this->groupBox13->Controls->Add(this->label73);
			this->groupBox13->Controls->Add(this->label72);
			this->groupBox13->Controls->Add(this->label71);
			this->groupBox13->Controls->Add(this->label70);
			this->groupBox13->Location = System::Drawing::Point(3, 355);
			this->groupBox13->Name = L"groupBox13";
			this->groupBox13->Size = System::Drawing::Size(405, 196);
			this->groupBox13->TabIndex = 4;
			this->groupBox13->TabStop = false;
			this->groupBox13->Text = L"�������:";
			// 
			// label89
			// 
			this->label89->AutoSize = true;
			this->label89->Location = System::Drawing::Point(289, 128);
			this->label89->Name = L"label89";
			this->label89->Size = System::Drawing::Size(13, 13);
			this->label89->TabIndex = 19;
			this->label89->Text = L"0";
			// 
			// label88
			// 
			this->label88->AutoSize = true;
			this->label88->Location = System::Drawing::Point(289, 102);
			this->label88->Name = L"label88";
			this->label88->Size = System::Drawing::Size(13, 13);
			this->label88->TabIndex = 18;
			this->label88->Text = L"0";
			// 
			// label87
			// 
			this->label87->AutoSize = true;
			this->label87->Location = System::Drawing::Point(289, 76);
			this->label87->Name = L"label87";
			this->label87->Size = System::Drawing::Size(13, 13);
			this->label87->TabIndex = 17;
			this->label87->Text = L"0";
			// 
			// label86
			// 
			this->label86->AutoSize = true;
			this->label86->Location = System::Drawing::Point(241, 128);
			this->label86->Name = L"label86";
			this->label86->Size = System::Drawing::Size(42, 13);
			this->label86->TabIndex = 16;
			this->label86->Text = L"��� x =";
			// 
			// label85
			// 
			this->label85->AutoSize = true;
			this->label85->Location = System::Drawing::Point(241, 102);
			this->label85->Name = L"label85";
			this->label85->Size = System::Drawing::Size(42, 13);
			this->label85->TabIndex = 15;
			this->label85->Text = L"��� x =";
			// 
			// label84
			// 
			this->label84->AutoSize = true;
			this->label84->Location = System::Drawing::Point(241, 76);
			this->label84->Name = L"label84";
			this->label84->Size = System::Drawing::Size(42, 13);
			this->label84->TabIndex = 14;
			this->label84->Text = L"��� x =";
			// 
			// label83
			// 
			this->label83->AutoSize = true;
			this->label83->Location = System::Drawing::Point(159, 180);
			this->label83->Name = L"label83";
			this->label83->Size = System::Drawing::Size(13, 13);
			this->label83->TabIndex = 13;
			this->label83->Text = L"0";
			// 
			// label82
			// 
			this->label82->AutoSize = true;
			this->label82->Location = System::Drawing::Point(4, 180);
			this->label82->Name = L"label82";
			this->label82->Size = System::Drawing::Size(145, 13);
			this->label82->TabIndex = 12;
			this->label82->Text = L"����� ����� ������� ����";
			// 
			// label81
			// 
			this->label81->AutoSize = true;
			this->label81->Location = System::Drawing::Point(160, 153);
			this->label81->Name = L"label81";
			this->label81->Size = System::Drawing::Size(13, 13);
			this->label81->TabIndex = 11;
			this->label81->Text = L"0";
			// 
			// label80
			// 
			this->label80->AutoSize = true;
			this->label80->Location = System::Drawing::Point(4, 153);
			this->label80->Name = L"label80";
			this->label80->Size = System::Drawing::Size(150, 13);
			this->label80->TabIndex = 10;
			this->label80->Text = L"����� ����� �������� ����";
			// 
			// label79
			// 
			this->label79->AutoSize = true;
			this->label79->Location = System::Drawing::Point(108, 128);
			this->label79->Name = L"label79";
			this->label79->Size = System::Drawing::Size(13, 13);
			this->label79->TabIndex = 9;
			this->label79->Text = L"0";
			// 
			// label78
			// 
			this->label78->AutoSize = true;
			this->label78->Location = System::Drawing::Point(5, 128);
			this->label78->Name = L"label78";
			this->label78->Size = System::Drawing::Size(34, 13);
			this->label78->TabIndex = 8;
			this->label78->Text = L"min hi";
			// 
			// label77
			// 
			this->label77->AutoSize = true;
			this->label77->Location = System::Drawing::Point(108, 102);
			this->label77->Name = L"label77";
			this->label77->Size = System::Drawing::Size(13, 13);
			this->label77->TabIndex = 7;
			this->label77->Text = L"0";
			// 
			// label76
			// 
			this->label76->AutoSize = true;
			this->label76->Location = System::Drawing::Point(5, 102);
			this->label76->Name = L"label76";
			this->label76->Size = System::Drawing::Size(37, 13);
			this->label76->TabIndex = 6;
			this->label76->Text = L"max hi";
			// 
			// label75
			// 
			this->label75->AutoSize = true;
			this->label75->Location = System::Drawing::Point(108, 76);
			this->label75->Name = L"label75";
			this->label75->Size = System::Drawing::Size(13, 13);
			this->label75->TabIndex = 5;
			this->label75->Text = L"0";
			// 
			// label74
			// 
			this->label74->AutoSize = true;
			this->label74->Location = System::Drawing::Point(5, 76);
			this->label74->Name = L"label74";
			this->label74->Size = System::Drawing::Size(63, 13);
			this->label74->TabIndex = 4;
			this->label74->Text = L"max | ��� |";
			// 
			// label73
			// 
			this->label73->AutoSize = true;
			this->label73->Location = System::Drawing::Point(108, 49);
			this->label73->Name = L"label73";
			this->label73->Size = System::Drawing::Size(13, 13);
			this->label73->TabIndex = 3;
			this->label73->Text = L"0";
			// 
			// label72
			// 
			this->label72->AutoSize = true;
			this->label72->Location = System::Drawing::Point(5, 49);
			this->label72->Name = L"label72";
			this->label72->Size = System::Drawing::Size(35, 13);
			this->label72->TabIndex = 2;
			this->label72->Text = L"b - Xn";
			// 
			// label71
			// 
			this->label71->AutoSize = true;
			this->label71->Location = System::Drawing::Point(108, 25);
			this->label71->Name = L"label71";
			this->label71->Size = System::Drawing::Size(13, 13);
			this->label71->TabIndex = 1;
			this->label71->Text = L"0";
			// 
			// label70
			// 
			this->label70->AutoSize = true;
			this->label70->Location = System::Drawing::Point(6, 25);
			this->label70->Name = L"label70";
			this->label70->Size = System::Drawing::Size(13, 13);
			this->label70->TabIndex = 0;
			this->label70->Text = L"n";
			// 
			// groupBox12
			// 
			this->groupBox12->Controls->Add(this->label67);
			this->groupBox12->Controls->Add(this->checkedListBox4);
			this->groupBox12->Controls->Add(this->textBox14);
			this->groupBox12->Location = System::Drawing::Point(0, 249);
			this->groupBox12->Name = L"groupBox12";
			this->groupBox12->Size = System::Drawing::Size(200, 100);
			this->groupBox12->TabIndex = 3;
			this->groupBox12->TabStop = false;
			this->groupBox12->Text = L"��������� �������� ��:";
			// 
			// label67
			// 
			this->label67->AutoSize = true;
			this->label67->Location = System::Drawing::Point(8, 77);
			this->label67->Name = L"label67";
			this->label67->Size = System::Drawing::Size(25, 13);
			this->label67->TabIndex = 2;
			this->label67->Text = L"Eps";
			// 
			// checkedListBox4
			// 
			this->checkedListBox4->FormattingEnabled = true;
			this->checkedListBox4->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"��� ��������", L"� ���������" });
			this->checkedListBox4->Location = System::Drawing::Point(8, 19);
			this->checkedListBox4->Name = L"checkedListBox4";
			this->checkedListBox4->Size = System::Drawing::Size(120, 49);
			this->checkedListBox4->TabIndex = 1;
			// 
			// textBox14
			// 
			this->textBox14->Location = System::Drawing::Point(39, 74);
			this->textBox14->Name = L"textBox14";
			this->textBox14->Size = System::Drawing::Size(89, 20);
			this->textBox14->TabIndex = 0;
			this->textBox14->Text = L"0,0000001";
			// 
			// groupBox11
			// 
			this->groupBox11->Controls->Add(this->textBox12);
			this->groupBox11->Controls->Add(this->label63);
			this->groupBox11->Controls->Add(this->textBox10);
			this->groupBox11->Controls->Add(this->label61);
			this->groupBox11->Location = System::Drawing::Point(3, 87);
			this->groupBox11->Name = L"groupBox11";
			this->groupBox11->Size = System::Drawing::Size(200, 50);
			this->groupBox11->TabIndex = 2;
			this->groupBox11->TabStop = false;
			this->groupBox11->Text = L"��������� �������:";
			// 
			// textBox12
			// 
			this->textBox12->Location = System::Drawing::Point(142, 17);
			this->textBox12->Name = L"textBox12";
			this->textBox12->Size = System::Drawing::Size(29, 20);
			this->textBox12->TabIndex = 6;
			this->textBox12->Text = L"3";
			// 
			// label63
			// 
			this->label63->AutoSize = true;
			this->label63->Location = System::Drawing::Point(97, 20);
			this->label63->Name = L"label63";
			this->label63->Size = System::Drawing::Size(39, 13);
			this->label63->TabIndex = 0;
			this->label63->Text = L"u\'(0) = ";
			// 
			// textBox10
			// 
			this->textBox10->Location = System::Drawing::Point(42, 17);
			this->textBox10->Name = L"textBox10";
			this->textBox10->Size = System::Drawing::Size(29, 20);
			this->textBox10->TabIndex = 3;
			this->textBox10->Text = L"5";
			// 
			// label61
			// 
			this->label61->AutoSize = true;
			this->label61->Location = System::Drawing::Point(2, 20);
			this->label61->Name = L"label61";
			this->label61->Size = System::Drawing::Size(34, 13);
			this->label61->TabIndex = 0;
			this->label61->Text = L"u(0) =";
			// 
			// groupBox10
			// 
			this->groupBox10->Controls->Add(this->label66);
			this->groupBox10->Controls->Add(this->label65);
			this->groupBox10->Controls->Add(this->label62);
			this->groupBox10->Controls->Add(this->textBox13);
			this->groupBox10->Controls->Add(this->textBox11);
			this->groupBox10->Controls->Add(this->textBox6);
			this->groupBox10->Location = System::Drawing::Point(3, 143);
			this->groupBox10->Name = L"groupBox10";
			this->groupBox10->Size = System::Drawing::Size(197, 100);
			this->groupBox10->TabIndex = 1;
			this->groupBox10->TabStop = false;
			this->groupBox10->Text = L"��������� ������:";
			// 
			// label66
			// 
			this->label66->AutoSize = true;
			this->label66->Location = System::Drawing::Point(4, 72);
			this->label66->Name = L"label66";
			this->label66->Size = System::Drawing::Size(104, 13);
			this->label66->TabIndex = 5;
			this->label66->Text = L"������ ������� (b)";
			// 
			// label65
			// 
			this->label65->AutoSize = true;
			this->label65->Location = System::Drawing::Point(4, 46);
			this->label65->Name = L"label65";
			this->label65->Size = System::Drawing::Size(37, 13);
			this->label65->TabIndex = 4;
			this->label65->Text = L"N max";
			// 
			// label62
			// 
			this->label62->AutoSize = true;
			this->label62->Location = System::Drawing::Point(2, 23);
			this->label62->Name = L"label62";
			this->label62->Size = System::Drawing::Size(86, 13);
			this->label62->TabIndex = 3;
			this->label62->Text = L"��������� ���";
			// 
			// textBox13
			// 
			this->textBox13->Location = System::Drawing::Point(111, 69);
			this->textBox13->Name = L"textBox13";
			this->textBox13->Size = System::Drawing::Size(77, 20);
			this->textBox13->TabIndex = 2;
			this->textBox13->Text = L"50";
			// 
			// textBox11
			// 
			this->textBox11->Location = System::Drawing::Point(47, 43);
			this->textBox11->Name = L"textBox11";
			this->textBox11->Size = System::Drawing::Size(77, 20);
			this->textBox11->TabIndex = 1;
			this->textBox11->Text = L"500";
			// 
			// textBox6
			// 
			this->textBox6->Location = System::Drawing::Point(94, 20);
			this->textBox6->Name = L"textBox6";
			this->textBox6->Size = System::Drawing::Size(77, 20);
			this->textBox6->TabIndex = 0;
			this->textBox6->Text = L"0,01";
			// 
			// pictureBox3
			// 
			this->pictureBox3->Image = (cli::safe_cast<System::Drawing::Image^>(resources->GetObject(L"pictureBox3.Image")));
			this->pictureBox3->Location = System::Drawing::Point(3, 3);
			this->pictureBox3->Name = L"pictureBox3";
			this->pictureBox3->Size = System::Drawing::Size(197, 53);
			this->pictureBox3->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox3->TabIndex = 0;
			this->pictureBox3->TabStop = false;
			// 
			// label21
			// 
			this->label21->AutoSize = true;
			this->label21->Location = System::Drawing::Point(15, 62);
			this->label21->Name = L"label21";
			this->label21->Size = System::Drawing::Size(25, 13);
			this->label21->TabIndex = 11;
			this->label21->Text = L"Eps";
			// 
			// checkedListBox2
			// 
			this->checkedListBox2->FormattingEnabled = true;
			this->checkedListBox2->Items->AddRange(gcnew cli::array< System::Object^  >(2) { L"��� ��������", L"� ���������" });
			this->checkedListBox2->Location = System::Drawing::Point(9, 19);
			this->checkedListBox2->Name = L"checkedListBox2";
			this->checkedListBox2->Size = System::Drawing::Size(120, 34);
			this->checkedListBox2->TabIndex = 2;
			// 
			// textBox22
			// 
			this->textBox22->Location = System::Drawing::Point(46, 59);
			this->textBox22->Name = L"textBox22";
			this->textBox22->Size = System::Drawing::Size(83, 20);
			this->textBox22->TabIndex = 1;
			// 
			// MyForm
			// 
			this->ClientSize = System::Drawing::Size(1258, 588);
			this->Controls->Add(this->tabControl1);
			this->Name = L"MyForm";
			this->Text = L"LabNM21";
			this->tabControl1->ResumeLayout(false);
			this->tabPage1->ResumeLayout(false);
			this->tabPage1->PerformLayout();
			this->groupBox4->ResumeLayout(false);
			this->groupBox4->PerformLayout();
			this->groupBox5->ResumeLayout(false);
			this->groupBox5->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView2))->EndInit();
			this->tabPage2->ResumeLayout(false);
			this->tabPage2->PerformLayout();
			this->groupBox8->ResumeLayout(false);
			this->groupBox8->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView3))->EndInit();
			this->groupBox9->ResumeLayout(false);
			this->groupBox9->PerformLayout();
			this->groupBox7->ResumeLayout(false);
			this->groupBox7->PerformLayout();
			this->groupBox6->ResumeLayout(false);
			this->groupBox6->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox2))->EndInit();
			this->tabPage3->ResumeLayout(false);
			this->tabPage3->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView4))->EndInit();
			this->groupBox13->ResumeLayout(false);
			this->groupBox13->PerformLayout();
			this->groupBox12->ResumeLayout(false);
			this->groupBox12->PerformLayout();
			this->groupBox11->ResumeLayout(false);
			this->groupBox11->PerformLayout();
			this->groupBox10->ResumeLayout(false);
			this->groupBox10->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox3))->EndInit();
			this->ResumeLayout(false);
		}
#pragma endregion
	private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) // ��������
	{
		GraphPane^ panel = zedGraphControl2->GraphPane;
		panel->CurveList->Clear();
		PointPairList^ f1_list = gcnew ZedGraph::PointPairList();
		PointPairList^ f2_list = gcnew ZedGraph::PointPairList();
		
		double h = Convert::ToDouble(textBox9->Text);
		double u0 = Convert::ToDouble(textBox7->Text);
		int Nmax = Convert::ToInt32(textBox4->Text);
		double rightBorder = Convert::ToDouble(textBox5->Text);
		double epsError = Convert::ToDouble(textBox8->Text);
		double prevX, prevV;

		//�������
		double maxui = 0, xForMaxui = 0;
		double maxhi = h, xForMaxhi = 0;
		double minhi = h, xForMinhi = 0;
		double maxS = 0, xForMaxS = 0;
		double sumHalf = 0, sumDouble = 0;

		Method testExample;
		Method testExampleWithHalfSteps;
		testExample.setH(h);
		testExample.setV0(u0);
		testExample.setVi(u0);
		testExample.setVi(u0);
		testExample.setXi(0);
		testExample.setEpsError(epsError);

		testExampleWithHalfSteps.setH(h);
		testExampleWithHalfSteps.setV0(u0);
		testExampleWithHalfSteps.setVi(u0);
		testExampleWithHalfSteps.setVi(u0);
		testExampleWithHalfSteps.setXi(0);
		testExampleWithHalfSteps.setEpsError(epsError);

		int i = 1;
		if (checkedListBox1->GetItemChecked(0) == true) // ��� �������� ��
		{
			dataGridView2->Rows->Add();
			dataGridView2->Rows[0]->Cells[0]->Value = 0;
			dataGridView2->Rows[0]->Cells[1]->Value = testExample.getH();
			dataGridView2->Rows[0]->Cells[2]->Value = testExample.getXi();
			dataGridView2->Rows[0]->Cells[3]->Value = testExample.getVi();
			dataGridView2->Rows[0]->Cells[9]->Value = testExample.getV0();
			dataGridView2->Rows[0]->Cells[10]->Value = fabs(testExample.getV0() - testExample.getV0());

			while (i < Nmax)
			{
				//������ � �������
				testExample.RK4forTest(testExample.getH());

				if (testExample.getXi() >= rightBorder) break;
				dataGridView2->Rows->Add();
				dataGridView2->Rows[i]->Cells[0]->Value = i;
				dataGridView2->Rows[i]->Cells[1]->Value = testExample.getH();
				dataGridView2->Rows[i]->Cells[2]->Value = testExample.getXi();
				dataGridView2->Rows[i]->Cells[3]->Value = testExample.getVi();
				dataGridView2->Rows[i]->Cells[9]->Value = testExample.getui(testExample.getXi());
				dataGridView2->Rows[i]->Cells[10]->Value = fabs(testExample.getVi() - testExample.getui(testExample.getXi())); 
				if (fabs(testExample.getVi() - testExample.getui(testExample.getXi())) > maxui)
				{
					maxui = fabs(testExample.getVi() - testExample.getui(testExample.getXi()));  
					xForMaxui = testExample.getXi();
				}
				f1_list->Add(testExample.getXi(), testExample.getui(testExample.getXi()));
				f2_list->Add(testExample.getXi(), testExample.getVi());

				i++;
			}
			LineItem Curve1 = panel->AddCurve("������ �������", f1_list, Color::Red, SymbolType::Triangle);
			LineItem Curve2 = panel->AddCurve("��������� �������", f2_list, Color::Black, SymbolType::TriangleDown);

			zedGraphControl2->AxisChange();
			// ��������� ������
			zedGraphControl2->Invalidate();
			
			label26->Text = i.ToString();
			label27->Text = (rightBorder- testExample.getXi()).ToString();
			label28->Text = "�������� �� ����������"; label34->Text = "�������� �� ����������";
			label29->Text = h.ToString(); label30->Text = "����";
			label31->Text = h.ToString(); label32->Text = "����";

			label35->Text = maxui.ToString();
			label36->Text = xForMaxui.ToString();
		}
		else if (checkedListBox1->GetItemChecked(1) == true) // c ��������� ��
		{
			int doubleCount = 0, halfCount = 0;
			int i = 1;

			dataGridView2->Rows->Add();
			dataGridView2->Rows[0]->Cells[0]->Value = 0;
			dataGridView2->Rows[0]->Cells[1]->Value = testExample.getH();
			dataGridView2->Rows[0]->Cells[2]->Value = testExample.getXi();
			dataGridView2->Rows[0]->Cells[3]->Value = testExample.getVi();
			dataGridView2->Rows[0]->Cells[4]->Value = testExampleWithHalfSteps.getVi();
			dataGridView2->Rows[0]->Cells[5]->Value = testExample.getVi() - testExampleWithHalfSteps.getVi();
			dataGridView2->Rows[0]->Cells[6]->Value = testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi());
			dataGridView2->Rows[0]->Cells[7]->Value = halfCount;
			dataGridView2->Rows[0]->Cells[8]->Value = doubleCount;
			dataGridView2->Rows[0]->Cells[9]->Value = testExample.getV0();
			dataGridView2->Rows[0]->Cells[10]->Value = fabs(testExample.getV0() - testExample.getV0());

			while (i < Nmax)
			{
				testExample.RK4forTest(testExample.getH());
				testExampleWithHalfSteps.RK4forTest(testExample.getHalfH());
				testExampleWithHalfSteps.RK4forTest(testExample.getHalfH());

				if (testExample.getXi() >= rightBorder) break;
				dataGridView2->Rows->Add();
				dataGridView2->Rows[i]->Cells[0]->Value = i;
				dataGridView2->Rows[i]->Cells[1]->Value = testExample.getH();
				if (testExample.getH() > maxhi)
				{
					maxhi = testExample.getH();
					xForMaxhi = testExample.getXi();
				}
				if (testExample.getH() < minhi)
				{
					minhi = testExample.getH();
					xForMinhi = testExample.getXi();
				}
				dataGridView2->Rows[i]->Cells[2]->Value = testExample.getXi();
				dataGridView2->Rows[i]->Cells[3]->Value = testExample.getVi();
				dataGridView2->Rows[i]->Cells[4]->Value = testExampleWithHalfSteps.getVi();
				dataGridView2->Rows[i]->Cells[5]->Value = testExample.getVi() - testExampleWithHalfSteps.getVi();
				dataGridView2->Rows[i]->Cells[6]->Value = testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi());
				if (testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi()) > maxS)
				{
					maxS = testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi());
					xForMaxS = testExample.getXi();
				}
				dataGridView2->Rows[i]->Cells[7]->Value = halfCount; halfCount = 0;
				dataGridView2->Rows[i]->Cells[8]->Value = doubleCount; doubleCount = 0;
				dataGridView2->Rows[i]->Cells[9]->Value = testExample.getui(testExample.getXi());
				dataGridView2->Rows[i]->Cells[10]->Value = fabs(testExample.getVi() - testExample.getui(testExample.getXi())); 
				if (fabs(testExample.getVi() - testExample.getui(testExample.getXi())) > maxui)
				{
					maxui = fabs(testExample.getVi() - testExample.getui(testExample.getXi()));
					xForMaxui = testExample.getXi();
				}

				while ((testExample.tooBig(testExample.getVi(), testExampleWithHalfSteps.getVi())) || (testExample.tooSmall(testExample.getVi(), testExampleWithHalfSteps.getVi())))
				{
					if (testExample.tooBig(testExample.getVi(), testExampleWithHalfSteps.getVi()))
					{
						testExample.goBack();
						testExample.doHalfH();

						testExampleWithHalfSteps.setXi(testExample.getXi());
						testExampleWithHalfSteps.setVi(testExample.getVi());
						testExampleWithHalfSteps.setH(testExample.getH() / 2);

						testExample.RK4forTest(testExample.getH());
						testExampleWithHalfSteps.RK4forTest(testExampleWithHalfSteps.getH());
						testExampleWithHalfSteps.RK4forTest(testExampleWithHalfSteps.getH());
						halfCount ++;
						sumHalf++;
						
						dataGridView2->Rows->Add();
						dataGridView2->Rows[i]->Cells[0]->Value = i;
						dataGridView2->Rows[i]->Cells[1]->Value = testExample.getH();
						if (testExample.getH() > maxhi)
						{
							maxhi = testExample.getH();
							xForMaxhi = testExample.getXi();
						}
						if (testExample.getH() < minhi)
						{
							minhi = testExample.getH();
							xForMinhi = testExample.getXi();
						}
						
						dataGridView2->Rows[i]->Cells[2]->Value = testExample.getXi();
						dataGridView2->Rows[i]->Cells[3]->Value = testExample.getVi();
						dataGridView2->Rows[i]->Cells[4]->Value = testExampleWithHalfSteps.getVi();
						dataGridView2->Rows[i]->Cells[5]->Value = testExample.getVi() - testExampleWithHalfSteps.getVi();
						dataGridView2->Rows[i]->Cells[6]->Value = testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi());
						
						if (testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi()) > maxS)
						{
							maxS = testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi());
							xForMaxS = testExample.getXi();
						}
						dataGridView2->Rows[i]->Cells[7]->Value = halfCount;
						dataGridView2->Rows[i]->Cells[9]->Value = testExample.getui(testExample.getXi());
						dataGridView2->Rows[i]->Cells[10]->Value = fabs(testExample.getVi() - testExample.getui(testExample.getXi())); 
						if (fabs(testExample.getVi() - testExample.getui(testExample.getXi())) > maxui)
						{
							maxui = fabs(testExample.getVi() - testExample.getui(testExample.getXi()));
							xForMaxui = testExample.getXi();
						}
					}
					else if (testExample.tooSmall(testExample.getVi(), testExampleWithHalfSteps.getVi()))
					{
						testExample.doDoubleH();
						doubleCount ++;
						sumDouble++;
						break;
					}
				}
				
				halfCount = 0;
				
				f1_list->Add(testExample.getXi(), testExample.getui(testExample.getXi()));
				f2_list->Add(testExample.getXi(), testExampleWithHalfSteps.getVi());
		
				i++;
			}

			LineItem Curve1 = panel->AddCurve("������ �������", f1_list, Color::Red, SymbolType::Plus);
			LineItem Curve2 = panel->AddCurve("��������� �������", f2_list, Color::Black, SymbolType::TriangleDown);

			zedGraphControl2->AxisChange();
			// ��������� ������
			zedGraphControl2->Invalidate();
			
			label26->Text = i.ToString();
			label27->Text = (rightBorder - testExample.getXi()).ToString();
			label28->Text = maxS.ToString(); label34->Text = xForMaxS.ToString();
			label29->Text = maxhi.ToString(); label30->Text = xForMaxhi.ToString();
			label31->Text = minhi.ToString(); label32->Text = xForMinhi.ToString();

			label35->Text = maxui.ToString();
			label36->Text = xForMaxui.ToString();
			
			label38->Text = sumDouble.ToString();
			label40->Text = sumHalf.ToString();
	    }
	}

	private: System::Void button4_Click(System::Object^  sender, System::EventArgs^  e) // ������ ��������
	{
		GraphPane^ panel = zedGraphControl3->GraphPane;
		panel->CurveList->Clear();
		PointPairList^ f1_list = gcnew ZedGraph::PointPairList();
		PointPairList^ f2_list = gcnew ZedGraph::PointPairList();

		double h = Convert::ToDouble(textBox20->Text);
		double u0 = Convert::ToDouble(textBox18->Text);
		int Nmax = Convert::ToInt32(textBox21->Text);
		double rightBorder = Convert::ToDouble(textBox19->Text);
		double epsError = Convert::ToDouble(textBox23->Text);

		//�������
		double maxui = 0, xForMaxui = 0;
		double maxhi = h, xForMaxhi = 0;
		double minhi = h, xForMinhi = 0;
		double maxS = 0, xForMaxS = 0;
		double sumHalf = 0, sumDouble = 0;
		
		Method testExample;
		Method testExampleWithHalfSteps;

		testExample.setH(h);
		testExample.setV0(u0);
		testExample.setVi(u0);
		testExample.setVi(u0);
		testExample.setXi(0);
		testExample.setEpsError(epsError);
		testExampleWithHalfSteps.setH(h);
		testExampleWithHalfSteps.setV0(u0);
		testExampleWithHalfSteps.setVi(u0);
		testExampleWithHalfSteps.setVi(u0);
		testExampleWithHalfSteps.setXi(0);
		testExampleWithHalfSteps.setEpsError(epsError);

		int i = 1;
		if (checkedListBox3->GetItemChecked(0) == true) // ��� �������� ��
		{
			dataGridView3->Rows->Add();
			dataGridView3->Rows[0]->Cells[0]->Value = 0;
			dataGridView3->Rows[0]->Cells[1]->Value = testExample.getH();
			dataGridView3->Rows[0]->Cells[2]->Value = testExample.getXi();
			dataGridView3->Rows[0]->Cells[3]->Value = testExample.getVi();
			f2_list->Add(testExample.getXi(), testExample.getVi());
			
			while (i < Nmax)
			{
				//������ � �������
				testExample.RK4forFirstMain(testExample.getH());
				
				if (testExample.getXi() >= rightBorder) break;
				dataGridView3->Rows->Add();
				dataGridView3->Rows[i]->Cells[0]->Value = i;
				dataGridView3->Rows[i]->Cells[1]->Value = testExample.getH();
				dataGridView3->Rows[i]->Cells[2]->Value = testExample.getXi();
				dataGridView3->Rows[i]->Cells[3]->Value = testExample.getVi();
				f2_list->Add(testExample.getXi(), testExample.getVi());

				i++;
			}
			
			LineItem Curve2 = panel->AddCurve("��������� �������", f2_list, Color::Black, SymbolType::TriangleDown);

			zedGraphControl3->AxisChange();
			// ��������� ������
			zedGraphControl3->Invalidate();

			label42->Text = i.ToString();
			label44->Text = (rightBorder - testExample.getXi()).ToString();
			label46->Text = "�������� �� ����������"; label48->Text = "�������� �� ����������";
			label50->Text = h.ToString(); label52->Text = "����";
			label54->Text = h.ToString(); label56->Text = "����";
		}
		else if (checkedListBox3->GetItemChecked(1) == true) // c ��������� ��
		{
			int doubleCount = 0, halfCount = 0;
			int i = 1;

			dataGridView3->Rows->Add();
			dataGridView3->Rows[0]->Cells[0]->Value = 0;
			dataGridView3->Rows[0]->Cells[1]->Value = testExample.getH();
			dataGridView3->Rows[0]->Cells[2]->Value = testExample.getXi();
			dataGridView3->Rows[0]->Cells[3]->Value = testExample.getVi();
			dataGridView3->Rows[0]->Cells[4]->Value = testExampleWithHalfSteps.getVi();
			dataGridView3->Rows[0]->Cells[5]->Value = testExample.getVi() - testExampleWithHalfSteps.getVi();
			dataGridView3->Rows[0]->Cells[6]->Value = testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi());
			dataGridView3->Rows[0]->Cells[7]->Value = halfCount;
			dataGridView3->Rows[0]->Cells[8]->Value = doubleCount;
			f2_list->Add(testExample.getXi(), testExample.getVi());

			while (i < Nmax)
			{
				testExample.RK4forFirstMain(testExample.getH());
				testExampleWithHalfSteps.RK4forFirstMain(testExample.getHalfH());
				testExampleWithHalfSteps.RK4forFirstMain(testExample.getHalfH());

				if (testExample.getXi() >= rightBorder) break;
				dataGridView3->Rows->Add();
				dataGridView3->Rows[i]->Cells[0]->Value = i;
				dataGridView3->Rows[i]->Cells[1]->Value = testExample.getH();
				if (testExample.getH() > maxhi)
				{
					maxhi = testExample.getH();
					xForMaxhi = testExample.getXi();
				}
				if (testExample.getH() < minhi)
				{
					minhi = testExample.getH();
					xForMinhi = testExample.getXi();
				}
				dataGridView3->Rows[i]->Cells[2]->Value = testExample.getXi();
				dataGridView3->Rows[i]->Cells[3]->Value = testExample.getVi();
				dataGridView3->Rows[i]->Cells[4]->Value = testExampleWithHalfSteps.getVi();
				dataGridView3->Rows[i]->Cells[5]->Value = testExample.getVi() - testExampleWithHalfSteps.getVi();
				dataGridView3->Rows[i]->Cells[6]->Value = testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi());
				if (testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi()) > maxS)
				{
					maxS = testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi());
					xForMaxS = testExample.getXi();
				}
				dataGridView3->Rows[i]->Cells[7]->Value = halfCount; halfCount = 0;
				dataGridView3->Rows[i]->Cells[8]->Value = doubleCount; doubleCount = 0;
				
				while ((testExample.tooBig(testExample.getVi(), testExampleWithHalfSteps.getVi())) || (testExample.tooSmall(testExample.getVi(), testExampleWithHalfSteps.getVi())))
				{
					if (testExample.tooBig(testExample.getVi(), testExampleWithHalfSteps.getVi()))
					{
						testExample.goBack();
						testExample.doHalfH();

						testExampleWithHalfSteps.setXi(testExample.getXi());
						testExampleWithHalfSteps.setVi(testExample.getVi());
						testExampleWithHalfSteps.setH(testExample.getH() / 2);

						testExample.RK4forFirstMain(testExample.getH());
						testExampleWithHalfSteps.RK4forFirstMain(testExampleWithHalfSteps.getH());
						testExampleWithHalfSteps.RK4forFirstMain(testExampleWithHalfSteps.getH());
						halfCount++;
						sumHalf++;

						dataGridView3->Rows->Add();
						dataGridView3->Rows[i]->Cells[0]->Value = i;
						dataGridView3->Rows[i]->Cells[1]->Value = testExample.getH();
						if (testExample.getH() > maxhi)
						{
							maxhi = testExample.getH();
							xForMaxhi = testExample.getXi();
						}
						if (testExample.getH() < minhi)
						{
							minhi = testExample.getH();
							xForMinhi = testExample.getXi();
						}
						dataGridView3->Rows[i]->Cells[2]->Value = testExample.getXi();
						dataGridView3->Rows[i]->Cells[3]->Value = testExample.getVi();
						dataGridView3->Rows[i]->Cells[4]->Value = testExampleWithHalfSteps.getVi();
						dataGridView3->Rows[i]->Cells[5]->Value = testExample.getVi() - testExampleWithHalfSteps.getVi();
						dataGridView3->Rows[i]->Cells[6]->Value = testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi());
						if (testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi()) > maxS)
						{
							maxS = testExample.getCountS(testExample.getVi(), testExampleWithHalfSteps.getVi());
							xForMaxS = testExample.getXi();
						}
						dataGridView3->Rows[i]->Cells[7]->Value = halfCount; 
					}
					else if (testExample.tooSmall(testExample.getVi(), testExampleWithHalfSteps.getVi()))
					{
						testExample.doDoubleH();
						doubleCount++;
						sumDouble++;
						break;
					}
				}

				halfCount = 0;

				f2_list->Add(testExample.getXi(), testExampleWithHalfSteps.getVi());

				i++;
			}

			LineItem Curve2 = panel->AddCurve("��������� �������", f2_list, Color::Black, SymbolType::TriangleDown);

			zedGraphControl3->AxisChange();
			// ��������� ������
			zedGraphControl3->Invalidate();

			label42->Text = i.ToString();
			label44->Text = (rightBorder - testExample.getXi()).ToString();
			label46->Text = maxS.ToString(); label48->Text = xForMaxS.ToString();
			label50->Text = maxhi.ToString(); label52->Text = xForMaxhi.ToString();
			label54->Text = minhi.ToString(); label56->Text = xForMinhi.ToString();
			label59->Text = sumDouble.ToString();
			label64->Text = sumHalf.ToString();
		}
	}

	private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) // ������ �������� ������ (�������)
	{
		GraphPane^ panel = zedGraphControl4->GraphPane;
		panel->CurveList->Clear();
		PointPairList^ f1_list = gcnew ZedGraph::PointPairList();
		PointPairList^ f2_list = gcnew ZedGraph::PointPairList();
		GraphPane^ panel1 = zedGraphControl5->GraphPane;
		panel1->CurveList->Clear();
		PointPairList^ f3_list = gcnew ZedGraph::PointPairList();

		double A = Convert::ToDouble(textBox15->Text);
		double B = Convert::ToDouble(textBox16->Text);
		double h = Convert::ToDouble(textBox6->Text);
		double u10 = Convert::ToDouble(textBox10->Text);
		double u20 = Convert::ToDouble(textBox12->Text);
		int Nmax = Convert::ToInt32(textBox11->Text);
		double rightBorder = Convert::ToDouble(textBox13->Text);
		double epsError = Convert::ToDouble(textBox14->Text);

		//�������
		double maxui = 0, xForMaxui = 0;
		double maxhi = h, xForMaxhi = 0;
		double minhi = h, xForMinhi = 0;
		double maxS = 0, xForMaxS = 0;
		double sumHalf = 0, sumDouble = 0;

		Method testExample;
		Method testExampleWithHalfSteps;

		testExample.setCoefForSystem(A, B);
		testExample.setH(h);
		testExample.setV10(u10);
		testExample.setV20(u20);
		testExample.setV1i(u10);
		testExample.setV2i(u20);
		testExample.setXi(0);
		testExample.setEpsError(epsError);
		testExampleWithHalfSteps.setH(h);
		testExampleWithHalfSteps.setV10(u10);
		testExampleWithHalfSteps.setV20(u20);
		testExampleWithHalfSteps.setV1i(u10);
		testExampleWithHalfSteps.setV2i(u20);
		testExampleWithHalfSteps.setXi(0);
		testExampleWithHalfSteps.setEpsError(epsError);
		
		int i = 1;
		if (checkedListBox4->GetItemChecked(0) == true) // ��� �������� ��
		{
			dataGridView4->Rows->Add();
			dataGridView4->Rows[0]->Cells[0]->Value = 0;
			dataGridView4->Rows[0]->Cells[1]->Value = testExample.getH();
			dataGridView4->Rows[0]->Cells[2]->Value = testExample.getXi();
			dataGridView4->Rows[0]->Cells[3]->Value = testExample.getV1i();
			dataGridView4->Rows[0]->Cells[4]->Value = testExample.getV2i();
			
			f1_list->Add(testExample.getXi(), testExample.getV1i());
			f2_list->Add(testExample.getXi(), testExample.getV2i());
			f3_list->Add(testExample.getV1i(), testExample.getV2i());

			while (i < Nmax)
			{
				//������ � �������
				testExample.RK4forSystem(testExample.getH());

				dataGridView4->Rows->Add();
				dataGridView4->Rows[i]->Cells[0]->Value = i;
				dataGridView4->Rows[i]->Cells[1]->Value = testExample.getH();
				dataGridView4->Rows[i]->Cells[2]->Value = testExample.getXi();
				dataGridView4->Rows[i]->Cells[3]->Value = testExample.getV1i();
				dataGridView4->Rows[i]->Cells[4]->Value = testExample.getV2i();

				f1_list->Add(testExample.getXi(), testExample.getV1i());
				f2_list->Add(testExample.getXi(), testExample.getV2i());
				f3_list->Add(testExample.getV1i(), testExample.getV2i());

				i++;
			}

			LineItem Curve1 = panel->AddCurve("V1(X)", f1_list, Color::BlueViolet, SymbolType::Triangle);
			LineItem Curve2 = panel->AddCurve("V2(x)", f2_list, Color::Black, SymbolType::TriangleDown);
			
			zedGraphControl4->AxisChange();
			// ��������� ������
			zedGraphControl4->Invalidate();

			LineItem Curve3 = panel1->AddCurve("V2(V1)", f3_list, Color::Black, SymbolType::TriangleDown);

			zedGraphControl5->AxisChange();
			// ��������� ������
			zedGraphControl5->Invalidate();

			label71->Text = i.ToString();
			label73->Text = (rightBorder - testExample.getXi()).ToString();
			label75->Text = "�������� �� ����������"; label87->Text = "�������� �� ����������";
			label77->Text = h.ToString(); label88->Text = "����";
			label79->Text = h.ToString(); label89->Text = "����";
		}
		else if (checkedListBox4->GetItemChecked(1) == true) // c ��������� �� 
		{
			int doubleCount = 0, halfCount = 0;
			int i = 1;

			dataGridView4->Rows->Add();
			dataGridView4->Rows[0]->Cells[0]->Value = 0;
			dataGridView4->Rows[0]->Cells[1]->Value = testExample.getH();
			dataGridView4->Rows[0]->Cells[2]->Value = testExample.getXi();
			dataGridView4->Rows[0]->Cells[3]->Value = testExample.getV1i();
			dataGridView4->Rows[0]->Cells[4]->Value = testExample.getV2i();
			dataGridView4->Rows[0]->Cells[5]->Value = testExampleWithHalfSteps.getV1i();
			dataGridView4->Rows[0]->Cells[6]->Value = testExampleWithHalfSteps.getV2i();
			dataGridView4->Rows[0]->Cells[7]->Value = testExample.getV1i() - testExampleWithHalfSteps.getV1i();
			dataGridView4->Rows[0]->Cells[8]->Value = testExample.getV2i() - testExampleWithHalfSteps.getV2i();
			dataGridView4->Rows[0]->Cells[9]->Value = testExample.getCountSforSystem(testExample.getV1i(), testExampleWithHalfSteps.getV1i(), testExample.getV2i(), testExampleWithHalfSteps.getV2i());
			dataGridView4->Rows[0]->Cells[10]->Value = halfCount;
			dataGridView4->Rows[0]->Cells[11]->Value = doubleCount;
			
			f1_list->Add(testExample.getXi(), testExample.getV1i());
			f2_list->Add(testExample.getXi(), testExample.getV2i());
			f3_list->Add(testExample.getV1i(), testExample.getV2i());

			while (i < Nmax)
			{
				testExample.RK4forSystem(testExample.getH());
				testExampleWithHalfSteps.RK4forSystem(testExample.getHalfH());
				testExampleWithHalfSteps.RK4forSystem(testExample.getHalfH());

				dataGridView4->Rows->Add();
				dataGridView4->Rows[i]->Cells[0]->Value = i;
				dataGridView4->Rows[i]->Cells[1]->Value = testExample.getH();
				if (testExample.getH() > maxhi)
				{
					maxhi = testExample.getH();
					xForMaxhi = testExample.getXi();
				}
				if (testExample.getH() < minhi)
				{
					minhi = testExample.getH();
					xForMinhi = testExample.getXi();
				}
				dataGridView4->Rows[i]->Cells[2]->Value = testExample.getXi();
				dataGridView4->Rows[i]->Cells[3]->Value = testExample.getV1i();
				dataGridView4->Rows[i]->Cells[4]->Value = testExample.getV2i();
				dataGridView4->Rows[i]->Cells[5]->Value = testExampleWithHalfSteps.getV1i();
				dataGridView4->Rows[i]->Cells[6]->Value = testExampleWithHalfSteps.getV2i();
				dataGridView4->Rows[i]->Cells[7]->Value = testExample.getV1i() - testExampleWithHalfSteps.getV1i();
				dataGridView4->Rows[i]->Cells[8]->Value = testExample.getV2i() - testExampleWithHalfSteps.getV2i();
				dataGridView4->Rows[i]->Cells[9]->Value = testExample.getCountSforSystem(testExample.getV1i(), testExampleWithHalfSteps.getV1i(), testExample.getV2i(), testExampleWithHalfSteps.getV2i());
				if (testExample.getCountSforSystem(testExample.getV1i(), testExampleWithHalfSteps.getV1i(), testExample.getV2i(), testExampleWithHalfSteps.getV2i()) > maxS)
				{
					maxS = testExample.getCountSforSystem(testExample.getV1i(), testExampleWithHalfSteps.getV1i(), testExample.getV2i(), testExampleWithHalfSteps.getV2i());
					xForMaxS = testExample.getXi();
				}
				dataGridView4->Rows[i]->Cells[10]->Value = halfCount; 
				dataGridView4->Rows[i]->Cells[11]->Value = doubleCount; doubleCount = 0;
				
				while (testExample.tooBigforSystem(testExample.getV1i(), testExampleWithHalfSteps.getV1i(), testExample.getV2i(), testExampleWithHalfSteps.getV2i()) || 
					testExample.tooSmallforSystem(testExample.getV1i(), testExampleWithHalfSteps.getV1i(), testExample.getV2i(), testExampleWithHalfSteps.getV2i()))
				{
					
					if (testExample.tooBigforSystem(testExample.getV1i(), testExampleWithHalfSteps.getV1i(), testExample.getV2i(), testExampleWithHalfSteps.getV2i()))
					{
						testExample.goBackforSystem();
						testExampleWithHalfSteps.goBackforSystem();
						testExample.doHalfH();
						testExampleWithHalfSteps.doHalfH();

						testExampleWithHalfSteps.setXi(testExample.getXi());
						testExampleWithHalfSteps.setV1i(testExample.getV1i());
						testExampleWithHalfSteps.setV2i(testExample.getV2i());
						testExampleWithHalfSteps.setH(testExample.getH() / 2);

						testExample.RK4forSystem(testExample.getH());
						testExampleWithHalfSteps.RK4forSystem(testExampleWithHalfSteps.getH());
						testExampleWithHalfSteps.RK4forSystem(testExampleWithHalfSteps.getH());
						halfCount++;
						sumHalf++;
						
						dataGridView4->Rows->Add();
						dataGridView4->Rows[i]->Cells[0]->Value = i;
						dataGridView4->Rows[i]->Cells[1]->Value = testExample.getH();
						if (testExample.getH() > maxhi)
						{
							maxhi = testExample.getH();
							xForMaxhi = testExample.getXi();
						}
						if (testExample.getH() < minhi)
						{
							minhi = testExample.getH();
							xForMinhi = testExample.getXi();
						}
						dataGridView4->Rows[i]->Cells[2]->Value = testExample.getXi();
						dataGridView4->Rows[i]->Cells[3]->Value = testExample.getV1i();
						dataGridView4->Rows[i]->Cells[4]->Value = testExample.getV2i();
						dataGridView4->Rows[i]->Cells[5]->Value = testExampleWithHalfSteps.getV1i();
						dataGridView4->Rows[i]->Cells[6]->Value = testExampleWithHalfSteps.getV2i();
						dataGridView4->Rows[i]->Cells[7]->Value = testExample.getV1i() - testExampleWithHalfSteps.getV1i();
						dataGridView4->Rows[i]->Cells[8]->Value = testExample.getV2i() - testExampleWithHalfSteps.getV2i();
						dataGridView4->Rows[i]->Cells[9]->Value = testExample.getCountSforSystem(testExample.getV1i(), testExampleWithHalfSteps.getV1i(), testExample.getV2i(), testExampleWithHalfSteps.getV2i());
						if (testExample.getCountSforSystem(testExample.getV1i(), testExampleWithHalfSteps.getV1i(), testExample.getV2i(), testExampleWithHalfSteps.getV2i()) > maxS)
						{
							maxS = testExample.getCountSforSystem(testExample.getV1i(), testExampleWithHalfSteps.getV1i(), testExample.getV2i(), testExampleWithHalfSteps.getV2i());
							xForMaxS = testExample.getXi();
						}
						dataGridView4->Rows[i]->Cells[10]->Value = halfCount; //halfCount = 0;
					}
					else if (testExample.tooSmallforSystem(testExample.getV1i(), testExampleWithHalfSteps.getV1i(), testExample.getV2i(), testExampleWithHalfSteps.getV2i()))
					{
						testExample.doDoubleH();
						doubleCount++;
						sumDouble++;
						break;
					}
				}
			
				halfCount = 0;

				f1_list->Add(testExample.getXi(), testExample.getV1i());
				f2_list->Add(testExample.getXi(), testExample.getV2i());
				f3_list->Add(testExample.getV1i(), testExample.getV2i());

				i++;
			}

			LineItem Curve1 = panel->AddCurve("V1(X)", f1_list, Color::BlueViolet, SymbolType::Triangle);
			LineItem Curve2 = panel->AddCurve("V2(x)", f2_list, Color::Black, SymbolType::TriangleDown);

			zedGraphControl4->AxisChange();
			// ��������� ������
			zedGraphControl4->Invalidate();

			LineItem Curve3 = panel1->AddCurve("V2(V1)", f3_list, Color::Black, SymbolType::TriangleDown);

			zedGraphControl5->AxisChange();
			// ��������� ������
			zedGraphControl5->Invalidate();

			label71->Text = i.ToString();
			label73->Text = (rightBorder - testExample.getXi()).ToString();
			label75->Text = maxS.ToString(); label87->Text = xForMaxS.ToString();
			label77->Text = maxhi.ToString(); label88->Text = xForMaxhi.ToString();
			label79->Text = minhi.ToString(); label89->Text = xForMinhi.ToString();
			label81->Text = sumDouble.ToString();
			label83->Text = sumHalf.ToString();
		}
}

	private: System::Void zedGraphControl1_Load(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
	}
	private: System::Void label1_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void label4_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void label6_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void label7_Click(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void groupBox3_Enter(System::Object^  sender, System::EventArgs^  e) {
	}
	private: System::Void label10_Click(System::Object^  sender, System::EventArgs^  e) {
	}
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {
	dataGridView2->Rows->Clear();
}

private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
}

private: System::Void button5_Click_1(System::Object^  sender, System::EventArgs^  e) {
	dataGridView3->Rows->Clear();
}

private: System::Void button3_Click_1(System::Object^  sender, System::EventArgs^  e) {
	dataGridView2->Rows->Clear();
}
private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e) {
	dataGridView4->Rows->Clear();
}
};
}