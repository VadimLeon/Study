﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace chm4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }

        public static double[] prog(int n, double h, double y0, double yn, double kappa1, double kappa2, double mu1, double mu2, double[] phi, double[] A, double[] B, double[] C)
        {
            double[] alfa = new double[n];
            double[] betta = new double[n];
            alfa[0] = kappa1;
            betta[0] = mu1;

            for (int i = 1; i < n - 2; i++)
            {
                alfa[i] = B[i] / (C[i] - alfa[i - 1] * A[i]);
                betta[i] = (phi[i] + A[i] * betta[i - 1]) / (C[i] - alfa[i - 1] * A[i]);
            }

            phi[n - 2] = mu2;

            double[] y = new double[n+1];
            y[n - 1] = (mu2 + kappa2 * betta[n - 3]) / (1 - kappa2* alfa[n - 3]);

            for (int i = n - 2; i > 0; i--)
            {
                y[i] = alfa[i - 1] * y[i + 1] + betta[i - 1];
            }

            y[0] = y0;
            y[n] = yn;

            return y;
        }

        private void draw(int n, double h)
        {
            chart1.Series[0].Points.Clear();
            chart1.Series[1].Points.Clear();

            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Maximum = 1;
            chart1.ChartAreas[0].AxisY.Minimum = -2;
            chart1.ChartAreas[0].AxisY.Maximum = 2;

            double x = 0;
            while (x < 1)
            {
                chart1.Series[0].Points.AddXY(x, test1.u(x));
                x += 0.01;
            }

            for (int i = 0; i < n + 1; i++)
            {
                chart1.Series[1].Points.AddXY(i * h, test1.v[i]);
            }


        }

        private void draw2(int n, double h)
        {

            chart1.Series[0].Points.Clear();
            chart1.Series[1].Points.Clear();

            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Maximum = 1;
            chart1.ChartAreas[0].AxisY.Minimum = -2;
            chart1.ChartAreas[0].AxisY.Maximum = 2;

            double x = 0;
            while (x < 1)
            {
                chart1.Series[0].Points.AddXY(x, test2.u(x));
                x += 0.01;
            }

            for (int i = 0; i <= n; i++)
            {
                chart1.Series[1].Points.AddXY(i * h, test2.v[i]);
            }
        }

        private void draw3(int n, double h)
        {
            chart1.Series[0].Points.Clear();
            chart1.Series[1].Points.Clear();

            chart1.ChartAreas[0].AxisX.Minimum = 0;
            chart1.ChartAreas[0].AxisX.Maximum = 1;
            chart1.ChartAreas[0].AxisY.Minimum = -2;
            chart1.ChartAreas[0].AxisY.Maximum = 2;

            for (int i = 0; i < n + 1; i++)
            {
                chart1.Series[0].Points.AddXY(i * h, maintask.v[i]);
                chart1.Series[1].Points.AddXY(i * h, maintask.v2[i*2]);
            }
        }

//------------------------Тестовая-задача-1-------------------------------------------------------//
        private void button1_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBox1.Text);
            double h = 1 / (Convert.ToDouble(n));

            test1.numerical_solution(n, h);

            draw(n, h);

            while (dataGridView1.RowCount > 1)
            {
                int r = dataGridView1.RowCount;
                dataGridView1.Rows.RemoveAt(dataGridView1.RowCount - 2);
            }

            int j = 0;

            while (j <= n)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[j].Cells[0].Value = (j).ToString();
                dataGridView1.Rows[j].Cells[1].Value = (j*h).ToString();
                dataGridView1.Rows[j].Cells[2].Value = (test1.u(j * h)).ToString();
                dataGridView1.Rows[j].Cells[3].Value = (test1.v[j]).ToString();
                dataGridView1.Rows[j].Cells[4].Value = (Math.Abs(test1.u(j * h) - test1.v[j])).ToString("0.####e-000");
                j++;
            }

            textBox2.Text = (test1.maxUV(n, h)).ToString("0.####e-000");
        }
//-----------------------------------------------------------------------------------------------//
        
        public static double[] Thomas_algorithm(int n, double[] d1, double[] d2, double[] d3, double[] val)
        {
            double[] alpha = new double[n + 1];
            double[] beta = new double[n + 1];
            double[] y = new double[n + 1];
            double[] A = new double[n];
            double[] B = new double[n];
            double[] C = new double[n];
            double[] phi = new double[n];
            double kapa1, kapa2, mu1, mu2;

            for (int i = 1; i < n; i++)
            {
                A[i] = d3[i];
                B[i] = d1[i + 1];
                C[i] = -d2[i + 1];
                phi[i] = -val[i + 1];
            }

            mu1 = val[1] / d2[1];
            mu2 = val[n + 1] / d2[n + 1];
            kapa1 = -(d1[1] / d2[1]);
            kapa2 = -(d3[n] / d2[n + 1]);

            alpha[1] = kapa1;
            beta[1] = mu1;

            for (int i = 1; i < n; i++)
            {
                alpha[i + 1] = B[i] / (C[i] - alpha[i] * A[i]);
                beta[i + 1] = (phi[i] + beta[i] * A[i]) / (C[i] - alpha[i] * A[i]);
            }

            y[n] = (mu2 + kapa2 * beta[n]) / (1 - kapa2 * alpha[n]);

            for (int i = n - 1; i > -1; i--)
            {
                y[i] = alpha[i + 1] * y[i + 1] + beta[i + 1];
            }
            return y;
        }


 //------------------------Тестовая-задача-2-------------------------------------------------------//
        private void button2_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBox1.Text);
            double h = 1 / (Convert.ToDouble(n));
            while (dataGridView1.RowCount > 1)
            {
                int r = dataGridView1.RowCount;
                dataGridView1.Rows.RemoveAt(dataGridView1.RowCount - 2);
            }

            test2.v = new double[n + 1]; 
            test2.numeratical_solution(n, h);
            test2.v[0] = test2.mu1;
            test2.v[n] = test2.mu2;

            draw2(n, h);

            int j = 0;
            while (j <= n)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[j].Cells[0].Value = (j).ToString();
                dataGridView1.Rows[j].Cells[1].Value = (j * h).ToString();
                dataGridView1.Rows[j].Cells[2].Value = (test2.u(h * j)).ToString();
                dataGridView1.Rows[j].Cells[3].Value = (test2.v[j]).ToString();
                dataGridView1.Rows[j].Cells[4].Value = (Math.Abs(test2.u(j * h) - test2.v[j])).ToString("0.####e-000");
                j++;
            }
            textBox2.Text = (test2.maxUV(n, h)).ToString("0.####e-000");
        }


 //------------------------Основная-задача------------------------------------------------------//
        private void button3_Click(object sender, EventArgs e)
        {
            int n = Convert.ToInt32(textBox1.Text);
            double h = 1 / (Convert.ToDouble(n));
            while (dataGridView1.RowCount > 1)
            {
                int r = dataGridView1.RowCount;
                dataGridView1.Rows.RemoveAt(dataGridView1.RowCount - 2);
            }

            maintask.numeratical_solution(n, h);
            int j = 0;
            while (j <= n)
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[j].Cells[0].Value = (j).ToString();
                dataGridView1.Rows[j].Cells[1].Value = (j * h).ToString();
                dataGridView1.Rows[j].Cells[2].Value = (maintask.v[j]).ToString();
                dataGridView1.Rows[j].Cells[3].Value = (maintask.v2[j]).ToString();
                dataGridView1.Rows[j].Cells[4].Value = (Math.Abs((maintask.v[j]) - (maintask.v2[2*j]))).ToString("0.####e-000");
                j++;
            }
            textBox2.Text = (maintask.max).ToString("0.####e-000");
            draw3(n, h);
        }
    }
}
