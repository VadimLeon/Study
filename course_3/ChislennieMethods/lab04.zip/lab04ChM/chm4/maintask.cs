﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chm4
{
    class maintask
    {
        public static double[] v = new double[10000];
        public static double[] v2 = new double[10000];
        public static double ksi = Math.PI / 4;
        public static double mu1 = 1;
        public static double mu2 = 0;
        public static double[] x;
        public static double max = 0;

        public static double k1(double x)
        {
           return Math.Sin(x) + 1;
        }

        public static double k2(double x)
        {
            return Math.Cos(x) * Math.Cos(x);
        }

        public static double q1(double x)
        { 
        return  1;
        }

        public static double q2(double x)
        { 
           return 2 * x * x; 
        }

        public static double f1(double x)
        {
            return Math.Sin(2 * x);
        }

        public static double f2(double x)
        {
            return Math.Cos(x);
        }

        public static double df1q1(double x)
        {
            return 2 * Math.Cos(2 * x);
        }

        public static double df2q2(double x)
        {
            return -(x * Math.Sin(x) + 2 * Math.Cos(x)) / (2 * Math.Pow(x, 3));
        }

        public static double[] A = new double[16];
        public static double[] b = new double[4];

        public static double l11(double x)
        {
            return Math.Sqrt(q1(x)/ k1(x));
        }
        public static double l12(double x)
        {
            return -l11(x);
        }

        public static double l21(double x)
        {
            return Math.Sqrt(q2(x) / k2(x));
        }
        public static double l22(double x)
        {
            return -l21(x);
        }

        public static double[] valA(double x)
        {
            A[0] = 1;
            A[1] = 1;
            A[2] = 0;
            A[3] = 0;

            A[4] = 0;
            A[5] = 0;
            A[6] = Math.Exp(-l21(x));
            A[7] = Math.Exp(-l22(x));

            A[8] = Math.Exp(-l11(x) * x);
            A[9] = Math.Exp(-l12(x) * x);
            A[10] = -Math.Exp(-l21(x) * x);
            A[11] = -Math.Exp(-l22(x) * x);

            A[12] = k1(x) * l11(x) * Math.Exp(-l11(x) * x);
            A[13] = k1(x) * l12(x) * Math.Exp(-l12(x) * x);
            A[14] = -k2(x) * l21(x) * Math.Exp(-l21(x) * x);
            A[15] = -k2(x) * l22(x) * Math.Exp(-l22(x) * x);

            return A;
        }

        public static double det(double[] A)
        {
            double a = A[0];
            double b = A[1];
            double c = A[2];
            double d = A[3];
            double e = A[4];
            double f = A[5];
            double g = A[6];
            double h = A[7];
            double i = A[8];
            double j = A[9];
            double k = A[10];
            double l = A[11];
            double m = A[12];
            double n = A[13];
            double o = A[14];
            double p = A[15];

            return a * f * k * p - a * f * l * o - a * g * j * p + a * g * l * n + a * h * j * o - a * h * k * n - b * e * k * p + b * e * l * o + b * g * i * p - b * g * l * m - b * h * i * o + b * h * k * m + c * e * j * p - c * e * l * n - c * f * i * p + c * f * l * m + c * h * i * n - c * h * j * m - d * e * j * o + d * e * k * n + d * f * i * o - d * f * k * m - d * g * i * n + d * g * j * m;
        }

        public static double u(double x)
        {
            double[] A = new double[16];
            A = valA(x);

            double detA = det(A);

            b[0] = mu1 - f1(x) / q1(x);
            b[1] = mu2 - f2(x) / q2(x);
            b[2] = f2(x) / q2(x) - f1(x) / q1(x);
            b[3] = k1(x) * df1q1(x) - k2(x) * df2q2(x);

            double[] A1 = new double[16];
            A1 = valA(x);
            A1[0] = b[0];
            A1[4] = b[1];
            A1[8] = b[2];
            A1[12] = b[3];
            double detA1 = det(A1);

            double[] A2 = new double[16];
            A2 = valA(x);
            A2[1] = b[0];
            A2[5] = b[1];
            A2[9] = b[2];
            A2[13] = b[3];
            double detA2 = det(A2);

            double[] A3 = new double[16];
            A3 = valA(x);
            A3[2] = b[0];
            A3[6] = b[1];
            A3[10] = b[2];
            A3[14] = b[3];
            double detA3 = det(A3);

            double[] A4 = new double[16];
            A4 = valA(x);
            A4[3] = b[0];
            A4[7] = b[1];
            A4[11] = b[2];
            A4[15] = b[3];
            double detA4 = det(A4);

            double C1, C2, C3, C4;
            C1 = detA1 / detA;
            C2 = detA2 / detA;
            C3 = detA3 / detA;
            C4 = detA4 / detA;

            if (x < ksi)
                return C1 * Math.Exp(-l11(x) * x) + C2 * Math.Exp(-l12(x) * x) + f1(x) / q1(x);
            else
                return C3 * Math.Exp(-l21(x) * x) + C4 * Math.Exp(-l22(x) * x) + f2(x) / q2(x);
        }

        public static void numeratical_solution(int n, double h)
        {
            double[] x = new double[n + 1];
            double[] x2 = new double[2 * n + 1];
            double[] V = new double[n + 1];
            double[] V2 = new double[2 * n + 1];
            double[] a = new double[n + 1];
            double[] a2 = new double[2 * n + 1];
            double[] func = new double[n];
            double[] func2 = new double[2 * n + 1];
            double[] d = new double[n];
            double[] d2 = new double[2 * n + 1];
            double[] dig1 = new double[n - 1];
            double[] dig1_2 = new double[2 * n - 1];
            double[] dig2 = new double[n];
            double[] dig2_2 = new double[2 * n];
            double[] dig3 = new double[n - 1];
            double[] dig3_2 = new double[2 * n - 1];
            double[] value = new double[n];
            double[] value2 = new double[2 * n];
            double h2 = h / 2;

            max = 0;

            for (int i = 0; i < n + 1; i++)
            {
                x[i] = i * h;
            }

            for (int i = 0; i < 2 * n + 1; i++)
                x2[i] = i * h2;

            for (int i = 1; i < n; i++)
            {
                if (ksi >= (x[i] + 0.5 * h))
                {
                    func[i] = f1(x[i]);
                    d[i] = q1(x[i]);
                }
                else if (ksi <= (x[i] - 0.5 * h))
                {
                    func[i] = f2(x[i]);
                    d[i] = q2(x[i]);
                }
                else
                {
                    func[i] = n * ((ksi - (x[i] - 0.5 * h)) * f1(0.5 * ((x[i] - 0.5 * h) + ksi)) + ((x[i] + 0.5 * h) - ksi) * f2(0.5 * (ksi + (x[i] + 0.5 * h))));
                    d[i] = n * ((ksi - (x[i] - 0.5 * h)) * q1(0.5 * (ksi + (x[i] - 0.5 * h))) + ((x[i] + 0.5 * h) - ksi) * q2(0.5 * ((x[i] + 0.5 * h) + ksi)));
                }


                if (ksi >= x[i])
                {
                    a[i] = 2 * k1(x[i]) * k1(x[i - 1]) / (k1(x[i - 1]) + k1(x[i]));
                }
                else if (ksi <= x[i - 1])
                {
                    a[i] = 2 * k2(x[i - 1]) * k2(x[i]) / (k2(x[i - 1]) + k2(x[i]));
                }
                else
                {
                    a[i] = 2 * h * k1(x[i - 1]) * k1(ksi) * k2(ksi) * k2(x[i]) / ((ksi - x[i - 1]) * (k1(ksi) + k1(x[i - 1])) * k2(ksi) * k2(x[i]) + (x[i] - ksi) * (k2(x[i]) + k2(ksi)) * k1(x[i - 1]) * k1(ksi));
                }
            }
            a[n] = 2 * k2(x[n]) * k2(x[n - 1]) / (k2(x[n - 1]) + k2(x[n]));

            V[0] = 1;
            V[n] = 0;

            for (int i = 1; i < 2 * n; ++i)
            {
                if (ksi >= (x2[i] + 0.5 * h2))
                {
                    func2[i] = f1(x2[i]);
                    d2[i] = q1(x2[i]);
                }
                else if (ksi <= (x2[i] - 0.5 * h2))
                {
                    func2[i] = f2(x2[i]);
                    d2[i] = q2(x2[i]);
                }
                else
                {
                    func2[i] = 2 * n * ((ksi - (x2[i] - 0.5 * h2)) * f1(0.5 * ((x2[i] - 0.5 * h2) + ksi)) + ((x2[i] + 0.5 * h2) - ksi) * f2(0.5 * (ksi + (x2[i] + 0.5 * h2))));
                    d2[i] = 2 * n * ((ksi - (x2[i] - 0.5 * h2)) * q1(0.5 * (ksi + (x2[i] - 0.5 * h2))) + ((x2[i] + 0.5 * h2) - ksi) * q2(0.5 * ((x2[i] + 0.5 * h2) + ksi)));
                }


                if (ksi >= x2[i])
                {
                    a2[i] = 2 * k1(x2[i]) * k1(x2[i - 1]) / (k1(x2[i - 1]) + k1(x2[i]));
                }
                else if (ksi <= x2[i - 1])
                {
                    a2[i] = 2 * k2(x2[i - 1]) * k2(x2[i]) / (k2(x2[i - 1]) + k2(x2[i]));
                }
                else
                {
                    a2[i] = 2 * h2 * k1(x2[i - 1]) * k1(ksi) * k2(ksi) * k2(x2[i]) / ((ksi - x2[i - 1]) * (k1(ksi) + k1(x2[i - 1])) * k2(ksi) * k2(x2[i]) + (x2[i] - ksi) * (k2(x2[i]) + k2(ksi)) * k1(x2[i - 1]) * k1(ksi));
                }

            }
            a2[2 * n] = 2 * k2(x2[2 * n]) * k2(x2[2 * n - 1]) / (k2(x2[2 * n - 1]) + k2(x2[2 * n]));

            V2[0] = 1;
            V2[2 * n] = 0;

            for (int i = 1; i < n - 1; ++i)
            {
                dig1[i] = a[i + 1] * n * n;
                dig2[i] = -(n * n * (a[i] + a[i + 1]) + d[i]);
                dig3[i] = a[i + 1] * n * n;
            }
            dig2[n - 1] = -(n * n * (a[n - 1] + a[n]) + d[n - 1]);

            for (int i = 1; i < n; i++)
                value[i] = -func[i];
            value[1] -= V[0] * a[1] * n * n;
            value[n - 1] -= V[n] * a[n] * n * n;

            double[] Solve = Form1.Thomas_algorithm(n - 2, dig1, dig2, dig3, value);
            for (int i = 1; i < n; ++i)
            {
                V[i] = Solve[i - 1];
                v[i] = V[i];
            }
            v[0] = 1;
            v[n] = 0;


            for (int i = 1; i < 2 * n - 1; ++i)
            {
                dig1_2[i] = a2[i + 1] * n * n * 4;
                dig2_2[i] = -(4 * n * n * (a2[i] + a2[i + 1]) + d2[i]);
                dig3_2[i] = a2[i + 1] * n * n * 4;
            }
            dig2_2[2 * n - 1] = -(4 * n * n * (a2[2 * n - 1] + a2[2 * n]) + d2[2 * n - 1]);

            for (int i = 1; i < 2 * n; i++)
                value2[i] = -func2[i];
            value2[1] -= V2[0] * a2[1] * n * n * 4;
            value2[2 * n - 1] -= V2[2 * n] * a2[2 * n] * n * n * 4;

            double[] Solve2 = Form1.Thomas_algorithm(2 * n - 2, dig1_2, dig2_2, dig3_2, value2);
            for (int i = 1; i < 2 * n; ++i)
            {
                V2[i] = Solve2[i - 1];
                v2[i] = V2[i];
            }

            v2[0] = 1;
            v2[2 * n] = 0;

            for (int i = 0; i < n + 1; i++)
            {
                if (Math.Abs(V[i] - V2[2 * i]) >= max)
                {
                    max = Math.Abs(V[i] - V2[2 * i]);
                }

            }

        }
    }
}
