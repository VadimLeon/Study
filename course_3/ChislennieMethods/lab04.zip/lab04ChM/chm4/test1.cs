﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chm4
{
    class test1
    {
        public static double q = 0;
        public static double f = -2;
        public static double k = 1;
        public static double v0 = -3;
        public static double vn = 3;
        public static double[] v;
        public static double u(double x)
        {
            return x * x + 5 * x - 3;
        }

        public static void numerical_solution(int n, double h)
        {
            double[] val = new double[n];
            double[] a = new double[n + 1];
            double[] d = new double[n];
            double[] d1 = new double[n - 1];
            double[] d2 = new double[n];
            double[] d3 = new double[n - 1];

            for (int i = 0; i < n; i++)
            {
                val[i] = f;
                d[i] = q;
                a[i] = k;
            }
            a[n] = k;

            v = new double[n + 1];

            v[0] = v0;
            v[n] = vn;

            for (int i = 1; i < n - 1; ++i)
            {
                d1[i] = a[i + 1] / (h * h);
                d2[i] = -(a[i] + a[i + 1] + d[i]) / (h * h);
                d3[i] = a[i + 1] * n * n;
            }
            d2[n - 1] = -((a[n - 1] + a[n]) + d[n - 1]) / (h * h);


            for (int i = 1; i < n; i++)
                val[i] = -f;
            val[1] -= v[0]  / (h * h);
            val[n - 1] -= v[n] * a[n] / (h * h);

            double[] V = Form1.Thomas_algorithm(n - 2, d1, d2, d3, val);
            for (int i = 1; i < n; i++)
                v[i] = V[i - 1];


        }

        public static double maxUV(int n, double h)
        {
            double max = 0;
            for (int i = 1; i < n; i++)
            {
                if (Math.Abs(u(i * h) - v[i]) > max)
                    max = Math.Abs(u(i * h) - v[i]);
            }

            return max;
        }
    }
}
