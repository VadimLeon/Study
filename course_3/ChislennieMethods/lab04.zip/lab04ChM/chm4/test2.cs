﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace chm4
{
    class test2
    {
        public static double[] v;
        public static double ksi = Math.PI / 4;
        public static double mu1 = 1;
        public static double mu2 = 0;
        public static double k1 = Math.Sin(ksi) + 1;
        public static double k2 = Math.Cos(ksi) * Math.Cos(ksi);
        public static double k(double x)
        {
            if (x < ksi) return k1;
            else return k2;
        }
        public static double q1 = 1;
        public static double q2 = 2 * ksi * ksi;
        public static double q(double x)
        {
            if (x < ksi) return q1;
            else return q2;
        }

        public static double f1 = Math.Sin(2 * ksi);
        public static double f2 = Math.Cos(ksi);

        public static double f(double x)
        {
            if (x < ksi) return f1;
            else return f2;
        }

        public static double df1q1 = 2 * Math.Cos(2*ksi);
        public static double df2q2 = -(ksi * Math.Sin(ksi) + 2 * Math.Cos(ksi)) / (2 * Math.Pow(ksi, 3));

        public static double[] A = new double[16];
        public static double[] b = new double[4];

        public static double l11 = Math.Sqrt(q1 / k1);
        public static double l12 = -l11;
        public static double l21 = Math.Sqrt(q2 / k2);
        public static double l22 = -l21;

        public static double[] valA()
        {
            A[0] = 1;
            A[1] = 1;
            A[2] = 0;
            A[3] = 0;

            A[4] = 0;
            A[5] = 0;
            A[6] = Math.Exp(-l21);
            A[7] = Math.Exp(-l22);

            A[8] = Math.Exp(-l11 * ksi);
            A[9] = Math.Exp(-l12 * ksi);
            A[10] = -Math.Exp(-l21 * ksi);
            A[11] = -Math.Exp(-l22 * ksi);

            A[12] = k1 * l11 * Math.Exp(-l11 * ksi);
            A[13] = k1 * l12 * Math.Exp(-l12 * ksi);
            A[14] = -k2 * l21 * Math.Exp(-l21 * ksi);
            A[15] = -k2 * l22 * Math.Exp(-l22 * ksi);

            return A;
        }

        public static double det( double[] A)
        {
            double a = A[0];
            double b = A[1];
            double c = A[2];
            double d = A[3];
            double e = A[4];
            double f = A[5];
            double g = A[6];
            double h = A[7];
            double i = A[8];
            double j = A[9];
            double k = A[10];
            double l = A[11];
            double m = A[12];
            double n = A[13];
            double o = A[14];
            double p = A[15];

            return a * f * k * p - a * f * l * o - a * g * j * p + a * g * l * n + a * h * j * o - a * h * k * n - b * e * k * p + b * e * l * o + b * g * i * p - b * g * l * m - b * h * i * o + b * h * k * m + c * e * j * p - c * e * l * n - c * f * i * p + c * f * l * m + c * h * i * n - c * h * j * m - d * e * j * o + d * e * k * n + d * f * i * o - d * f * k * m - d * g * i * n + d * g * j * m;
        }

        public static double u(double x)
        {
            double[]  A = new double[16];
            A = valA();

            double detA = det(A);

            b[0] = mu1 - f1 / q1;
            b[1] = mu2 - f2 / q2;
            b[2] = f2 / q2 - f1 / q1;
            b[3] = 0; //k1 * df1q1 - k2 * df2q2;

            double[] A1 = new double[16];
            A1 = valA();
            A1[0] = b[0];
            A1[4] = b[1];
            A1[8] = b[2];
            A1[12] = b[3];
            double detA1 = det(A1);

            double[] A2 = new double[16];
            A2 = valA();
            A2[1] = b[0];
            A2[5] = b[1];
            A2[9] = b[2];
            A2[13] = b[3];
            double detA2 = det(A2);

            double[] A3 = new double[16];
            A3 = valA();
            A3[2] = b[0];
            A3[6] = b[1];
            A3[10] = b[2];
            A3[14] = b[3];
            double detA3 = det(A3);

            double[] A4 = new double[16];
            A4 = valA();
            A4[3] = b[0];
            A4[7] = b[1];
            A4[11] = b[2];
            A4[15] = b[3];
            double detA4 = det(A4);

            double C1, C2, C3, C4;
            C1 = detA1 / detA;
            C2 = detA2 / detA;
            C3 = detA3 / detA;
            C4 = detA4 / detA;

            if (x < ksi)
                return C1 * Math.Exp(-l11 * x) + C2 * Math.Exp(-l12 * x) + f1 / q1;
            else
                return C3 * Math.Exp(-l21 * x) + C4 * Math.Exp(-l22 * x) + f2 / q2;
            
        }

        public static void numeratical_solution(double n, double h)
        {
             double[] x    = new double[(int)n + 1];
             double[] V    = new double[(int)n + 1];
             double[] a    = new double[(int)n + 1];
             double[] func = new double[(int)n];
             double[] d    = new double[(int)n];
             double[] dig1 = new double[(int)n - 1];
             double[] dig2 = new double[(int)n];
             double[] dig3 = new double[(int)n];
             double[] value = new double[(int)n];
             double[] U    = new double[(int)n + 1];

             for (int i = 0; i < n + 1; ++i)
                 x[i] = i * h;
             for (int i = 1; i < n; ++i)
             {
                 if (ksi >= (x[i]) + 0.5 * h)
                 {
                     func[i] = f1;
                     d[i] = q1;
                 }
                 else if (ksi <= (x[i] - 0.5 * h))
                 {
                     func[i] = f2;
                     d[i] = q2;
                 }
                 else
                 {
                     func[i] = n * ((ksi - (x[i] - 0.5 * h)) * f1 + ((x[i] + 0.5 * h) - ksi) * f2);
                     d[i] = n * ((ksi - (x[i] - 0.5 * h)) * q1 + ((x[i] + 0.5 * h) - ksi) * q2);
                 }

                 if (ksi >= x[i])
                 {
                     a[i] = k1;
                 }
                 else if (ksi <= (x[i - 1]))
                 {
                     a[i] = k2;
                 }
                 else
                 {
                     a[i] = 2 * h * k1 * k1 * k2 * k2 / ((ksi - x[i - 1]) * (k1 + k1) * k2 * k2 + (x[i] - ksi) * (k2 + k2) * k1 * k1);
                 }
             }
             a[(int)n] = k2;
             V[0] = 1;
             V[(int)n] = 0;

             for (int i = 1; i < n - 1; ++i)
             {
                 dig1[i] = a[i + 1] * n * n;
                 dig2[i] = -(n * n * (a[i] + a[i + 1]) + d[i]);
                 dig3[i] = a[i + 1] * n * n;
             }
             dig2[(int)n - 1] = -(n * n * (a[(int)n - 1] + a[(int)n]) + d[(int)n - 1]);

             for (int i = 1; i < n; i++)
                 value[i] = -func[i];

             value[1] -= V[0] * a[1] * n * n;
             value[(int)n - 1] -= V[(int)n] * a[(int)n] * n * n;

             double[] Solve = Form1.Thomas_algorithm((int)n - 2, dig1, dig2, dig3, value);
             for (int i = 1; i < n; ++i)
                 test2.v[i] = Solve[i - 1];
        }

        public static double maxUV(int n, double h)
        {
            double max = 0;
            for (int i = 1; i < n; i++)
            {
                if (Math.Abs(u(i * h) - v[i]) > max)
                    max = Math.Abs(u(i * h) - v[i]);
            }

            return max;
        }
    }
}
